package mchorse.bbs_mod.forms.forms;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.data.types.BaseType;
import mchorse.bbs_mod.data.types.IntType;
import mchorse.bbs_mod.data.types.MapType;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.ITickable;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.forms.utils.Anchor;
import mchorse.bbs_mod.forms.forms.utils.GlowSettings;
import mchorse.bbs_mod.forms.forms.utils.Illusion;
import mchorse.bbs_mod.forms.forms.utils.InverseKinematics;
import mchorse.bbs_mod.forms.forms.utils.LookAt;
import mchorse.bbs_mod.forms.forms.utils.PaintSettings;
import mchorse.bbs_mod.forms.forms.utils.TextureBlend;
import mchorse.bbs_mod.forms.states.AnimationState;
import mchorse.bbs_mod.forms.states.AnimationStates;
import mchorse.bbs_mod.forms.states.StatePlayer;
import mchorse.bbs_mod.forms.values.ValueAnchor;
import mchorse.bbs_mod.forms.values.ValueIllusion;
import mchorse.bbs_mod.forms.values.ValueInverseKinematics;
import mchorse.bbs_mod.forms.values.ValueLookAt;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.settings.values.core.ValueColor;
import mchorse.bbs_mod.settings.values.core.ValueGroup;
import mchorse.bbs_mod.settings.values.core.ValueString;
import mchorse.bbs_mod.settings.values.core.ValueTransform;
import mchorse.bbs_mod.settings.values.misc.ValueGlowSettings;
import mchorse.bbs_mod.settings.values.misc.ValuePaintSettings;
import mchorse.bbs_mod.settings.values.numeric.ValueBoolean;
import mchorse.bbs_mod.settings.values.numeric.ValueFloat;
import mchorse.bbs_mod.settings.values.numeric.ValueInt;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.StringUtils;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.keyframes.factories.KeyframeFactories;
import mchorse.bbs_mod.utils.pose.Transform;
import net.minecraft.class_1309;
import net.minecraft.class_5134;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class Form extends ValueGroup
{
    public final ValueBoolean visible = new ValueBoolean("visible", true);
    public final ValueBoolean render = new ValueBoolean("render", true);
    public final ValueBoolean animatable = new ValueBoolean("animatable", true);
    public final ValueString trackName = new ValueString("track_name", "");
    public final ValueFloat lighting = new ValueFloat("lighting", 1F);

    /* Mine-imator style render depth: forms with a lower value are drawn earlier, so a
     * semi-transparent form with lower render depth occludes forms behind it that have a
     * higher render depth (they fail the depth test instead of blending through). */
    public final ValueFloat renderDepth = new ValueFloat("render_depth", 0F);
    public final ValueBoolean renderDepthEnabled = new ValueBoolean("render_depth_enabled", false);
    public final ValueString name = new ValueString("name", "");
    public final ValueTransform transform = new ValueTransform("transform", new Transform());
    public final ValueTransform transformOverlay = new ValueTransform("transform_overlay", new Transform());
    public final ValueFloat uiScale = new ValueFloat("uiScale", 1F);
    public final ValueAnchor anchor = new ValueAnchor("anchor", new Anchor());
    public final ValueLookAt lookAt = new ValueLookAt("look_at", new LookAt());
    public final ValueInverseKinematics inverseKinematics = new ValueInverseKinematics("inverse_kinematics", new InverseKinematics());
    public final ValueBoolean shaderShadow = new ValueBoolean("shaderShadow", true);
    /**
     * Opacity-track "No shading" (Iris opacity-fix tradeoff): ON = redraw soft form after
     * paint so paint behind stays visible (pack body shadows lost). OFF = Iris soft path
     * keeps pack sun shadows on the mesh (paint behind stays depth-clipped). Legacy films
     * may still store this flag on Color keyframes.
     */
    public final ValueBoolean noshadingOpacity = new ValueBoolean("noshading_opacity", false);

    /**
     * Form display opacity (film Opacity track). Multiplied with {@code color.a} when rendering.
     * Blend Color keeps RGB on {@code color}; this float owns soft fades independently.
     */
    public final ValueFloat opacity = new ValueFloat("opacity", 1F, 0F, 1F);

    /* FS-style paint overlay: paintSettings controls color and intensity; paintColor is kept for backward compatibility */
    public final ValueColor paintColor = new ValueColor("paint_color", new Color().set(1F, 1F, 1F, 0F));
    public final ValuePaintSettings paintSettings = new ValuePaintSettings("paint", new PaintSettings());

    /* FS-style additive glow: glowingColor is RGB only; glowSettings controls brightness and spread */
    public final ValueColor glowingColor = new ValueColor("glowing_color", new Color().set(1F, 1F, 1F, 1F));
    public final ValueGlowSettings glowSettings = new ValueGlowSettings("glow", new GlowSettings());

    /* Illusions: purely visual duplicates of this form that spread away from it in
     * the picked directions (no extra entities, so they're cheap to render) */
    public final ValueIllusion illusion = new ValueIllusion("illusion", new Illusion());
    public final ValueIllusion illusionOverlay = new ValueIllusion("illusion_overlay", new Illusion());

    /* Extra transform that gets applied only to the illusions (optionally gradually
     * from the first illusion to the last one, see Illusion.gradual) */
    public final ValueTransform illusionTransform = new ValueTransform("illusion_transform", new Transform());
    public final ValueTransform illusionTransformOverlay = new ValueTransform("illusion_transform_overlay", new Transform());

    public final List<ValueTransform> additionalTransforms = new ArrayList<>();
    public final List<ValueIllusion> additionalIllusions = new ArrayList<>();
    public final List<ValueTransform> additionalIllusionTransforms = new ArrayList<>();
    /**
     * Extra Blend Color tracks (same count knob as pose/transform/illusion overlays).
     * Registered only by forms that expose a {@code color} property via {@link #registerColorOverlays()}.
     */
    public final ValueColor colorOverlay = new ValueColor("color_overlay", new Color(1F, 1F, 1F, 0F));
    public final List<ValueColor> additionalColors = new ArrayList<>();
    private transient boolean colorOverlaysRegistered;

    /* Hitbox properties */
    public final ValueBoolean hitbox = new ValueBoolean("hitbox", false);
    public final ValueFloat hitboxWidth = new ValueFloat("hitboxWidth", 0.5F);
    public final ValueFloat hitboxHeight = new ValueFloat("hitboxHeight", 1.8F);
    public final ValueFloat hitboxSneakMultiplier = new ValueFloat("hitboxSneakMultiplier", 0.9F);
    public final ValueFloat hitboxEyeHeight = new ValueFloat("hitboxEyeHeight", 0.9F);

    /* Morphing properties */
    public final ValueFloat hp = new ValueFloat("hp", 20F);
    public final ValueFloat speed = new ValueFloat("movement_speed", 0.1F);
    public final ValueFloat stepHeight = new ValueFloat("step_height", 0.5F);

    public final ValueInt hotkey = new ValueInt("keybind", 0);

    public final BodyPartManager parts = new BodyPartManager("parts");
    public final AnimationStates states = new AnimationStates("states");

    protected Object renderer;
    protected String cachedID;

    /** Bumped when any nested value changes; used for incremental entity sync and UI preview cache. */
    private transient int editRevision = 0;

    /** Runtime texture crossfade state driven by the film texture track bend keyframes. */
    public transient TextureBlend textureBlend;

    /** Runtime texture crossfade between illusion keyframes with bend enabled. */
    public transient TextureBlend illusionTextureBlend;

    private final List<StatePlayer> statePlayers = new ArrayList<>();

    public Form()
    {
        super("");

        this.animatable.invisible();
        this.trackName.invisible();
        this.name.invisible();
        this.uiScale.invisible();
        this.shaderShadow.invisible();
        this.noshadingOpacity.invisible();
        this.render.invisible();
        this.add(this.visible);
        this.add(this.render);
        this.add(this.animatable);
        this.add(this.trackName);
        this.add(this.lighting);
        this.add(this.renderDepth);

        /* The toggle isn't keyframable, so it shouldn't show up as a timeline track. */
        this.renderDepthEnabled.invisible();
        this.add(this.renderDepthEnabled);
        this.add(this.name);
        this.add(this.transform);
        this.add(this.transformOverlay);

        for (int i = 0; i < BBSSettings.recordingPoseTransformOverlays.get(); i++)
        {
            ValueTransform valueTransform = new ValueTransform("transform_overlay" + i, new Transform());

            this.additionalTransforms.add(valueTransform);
            this.add(valueTransform);
        }

        this.add(this.uiScale);
        this.add(this.anchor);
        this.add(this.lookAt);
        this.add(this.inverseKinematics);
        this.add(this.shaderShadow);
        this.add(this.noshadingOpacity);
        this.add(this.opacity);
        this.add(this.paintColor);
        this.add(this.paintSettings);
        this.add(this.glowingColor);
        this.add(this.glowSettings);

        this.add(this.illusion);
        this.add(this.illusionOverlay);

        for (int i = 0; i < BBSSettings.recordingPoseTransformOverlays.get(); i++)
        {
            ValueIllusion valueIllusion = new ValueIllusion("illusion_overlay" + i, new Illusion());

            this.additionalIllusions.add(valueIllusion);
            this.add(valueIllusion);
        }

        this.add(this.illusionTransform);
        this.add(this.illusionTransformOverlay);

        this.illusionTransform.invisible();
        this.illusionTransformOverlay.invisible();

        for (int i = 0; i < BBSSettings.recordingPoseTransformOverlays.get(); i++)
        {
            ValueTransform valueTransform = new ValueTransform("illusion_transform_overlay" + i, new Transform());

            valueTransform.invisible();
            this.additionalIllusionTransforms.add(valueTransform);
            this.add(valueTransform);
        }

        this.hitbox.invisible();
        this.hitboxWidth.invisible();
        this.hitboxHeight.invisible();
        this.hitboxSneakMultiplier.invisible();
        this.hitboxEyeHeight.invisible();

        this.add(this.hitbox);
        this.add(this.hitboxWidth);
        this.add(this.hitboxHeight);
        this.add(this.hitboxSneakMultiplier);
        this.add(this.hitboxEyeHeight);

        this.hp.invisible();
        this.speed.invisible();
        this.stepHeight.invisible();

        this.add(this.hp);
        this.add(this.speed);
        this.add(this.stepHeight);

        this.hotkey.invisible();

        this.add(this.hotkey);

        this.add(this.parts);
        this.add(this.states);
    }

    public Object getRenderer()
    {
        return this.renderer;
    }

    public void setRenderer(Object renderer)
    {
        this.renderer = renderer;
    }

    public Form getParentForm()
    {
        BaseValue parentValue = this.getParent();

        while (parentValue != null)
        {
            if (parentValue instanceof Form form)
            {
                return form;
            }

            parentValue = parentValue.getParent();
        }

        return null;
    }

    /* Animation states */

    public boolean findState(int hotkey, IStateFoundCallback callback)
    {
        if (callback == null)
        {
            return false;
        }

        for (AnimationState state : this.states.getAllTyped())
        {
            if (state.keybind.get() == hotkey)
            {
                callback.acceptState(this, state);

                return true;
            }
        }

        return false;
    }

    public void clearStatePlayers()
    {
        this.statePlayers.clear();
    }

    public void playState(AnimationState state)
    {
        if (state != null)
        {
            if (state.looping.get())
            {
                for (StatePlayer statePlayer : this.statePlayers)
                {
                    if (statePlayer.getState() == state)
                    {
                        statePlayer.expire();

                        return;
                    }
                }
            }

            this.statePlayers.add(new StatePlayer(state));
        }
    }

    public void playState(String stateId)
    {
        this.playState(this.states.getById(stateId));
    }

    public void playMain()
    {
        this.clearStatePlayers();
        this.playState(this.states.getMainRandom());
    }

    public void applyStates(float transition)
    {
        for (StatePlayer statePlayer : this.statePlayers)
        {
            statePlayer.assignValues(this, transition);
        }
    }

    public void unapplyStates()
    {
        for (StatePlayer statePlayer : this.statePlayers)
        {
            statePlayer.resetValues(this);
        }
    }

    /* Morphing */

    public void onMorph(class_1309 entity)
    {
        float hp = this.hp.get();
        float speed = this.speed.get();
        float stepHeight = this.stepHeight.get();

        if (hp != 20F)
        {
            entity.method_5996(class_5134.field_23716).method_6192(hp);
            entity.method_6033(hp);
        }
        if (speed != 0.1F) entity.method_5996(class_5134.field_23719).method_6192(speed);
        /* if (stepHeight != 0.5F) entity.setStepHeight(stepHeight); */
    }

    public void onDemorph(class_1309 entity)
    {
        entity.method_5996(class_5134.field_23716).method_6192(20F);
        entity.method_6033(20F);
        entity.method_5996(class_5134.field_23719).method_6192(0.1F);
        /* entity.setStepHeight(0.5F); */
    }

    /* ID and display name */

    public String getFormId()
    {
        if (this.cachedID == null)
        {
            this.cachedID = BBSMod.getForms().getType(this).toString();
        }

        return this.cachedID;
    }

    public String getFormIdOrName()
    {
        String name = this.name.get();

        return name.isEmpty() ? this.getFormId() : name;
    }

    public final String getDisplayName()
    {
        String name = this.name.get();

        if (!name.isEmpty())
        {
            return name;
        }

        return this.getDefaultDisplayName();
    }

    protected String getDefaultDisplayName()
    {
        return this.getFormId();
    }

    public final String getDefaultDisplayNameForHud()
    {
        return this.getDefaultDisplayName();
    }

    public String getTrackName(String property)
    {
        String s = this.trackName.get();

        if (!s.isEmpty())
        {
            if (property.isEmpty())
            {
                return s;
            }

            int slash = property.lastIndexOf('/');
            String last = slash == -1 ? property : property.substring(slash + 1);

            return s + (StringUtils.isInteger(last) ? "" : "/" + last);
        }

        return property;
    }

    /* Update */

    public void update(IEntity entity)
    {
        this.parts.update(entity);

        if (this.renderer instanceof ITickable)
        {
            ((ITickable) this.renderer).tick(entity);
        }

        Iterator<StatePlayer> it = this.statePlayers.iterator();

        while (it.hasNext())
        {
            StatePlayer next = it.next();

            next.update();

            if (next.canBeRemoved())
            {
                it.remove();
            }
        }
    }

    public int getEditRevision()
    {
        return this.editRevision;
    }

    @Override
    public void postNotify(BaseValue value, int flag)
    {
        this.editRevision += 1;

        super.postNotify(value, flag);
    }

    /* Data comparison and (de)serialization */

    @Override
    public void fromData(BaseType data)
    {
        if (data instanceof MapType map)
        {
            /* Compatibility with older forms */
            if (map.has("bodyParts"))
            {
                MapType bodyParts = map.getMap("bodyParts");

                if (bodyParts.has("parts"))
                {
                    map.remove("bodyParts");
                    map.put("parts", bodyParts.getList("parts"));
                }
            }

            if (map.has("glow_settings") && !map.has("glow"))
            {
                map.put("glow", map.get("glow_settings"));
                map.remove("glow_settings");
            }

            /* render_depth_enabled briefly defaulted to true and was written onto every morph.
             * Drop that baked-on state when depth was never customized (still 0). */
            this.stripLegacyDefaultRenderDepthEnabled(map);
        }

        super.fromData(data);

        if (data instanceof MapType map)
        {
            /* Prefer rich Color Grade / blend map saved beside legacy Int color. */
            if (map.has("color_bbs"))
            {
                BaseValue colorValue = this.get("color");

                if (colorValue instanceof ValueColor valueColor)
                {
                    valueColor.fromData(map.get("color_bbs"));
                }
            }

            if (map.has("glow"))
            {
                MapType glowMap = map.getMap("glow");

                if (!glowMap.has("r") && map.has("glowing_color"))
                {
                    GlowSettings settings = this.glowSettings.get().copy();
                    Color glowing = this.glowingColor.get();

                    settings.r = glowing.r;
                    settings.g = glowing.g;
                    settings.b = glowing.b;
                    this.glowSettings.set(settings);
                }
            }

            if (map.has("paint"))
            {
                MapType paintMap = map.getMap("paint");

                if (!paintMap.has("r") && map.has("paint_color"))
                {
                    PaintSettings settings = this.paintSettings.get().copy();
                    Color legacy = this.paintColor.get();

                    settings.r = legacy.r;
                    settings.g = legacy.g;
                    settings.b = legacy.b;
                    settings.intensity = PaintSettings.resolveLegacyPaintIntensity(legacy);
                    this.paintSettings.set(settings);
                }
            }
            else if (map.has("paint_color"))
            {
                PaintSettings settings = this.paintSettings.get().copy();
                Color legacy = this.paintColor.get();

                settings.r = legacy.r;
                settings.g = legacy.g;
                settings.b = legacy.b;
                settings.intensity = PaintSettings.resolveLegacyPaintIntensity(legacy);
                this.paintSettings.set(settings);
            }

            /* Compatibility with state triggers */
            FormUtils.readOldStateTriggers(this, map);

            /* Split legacy color.a into opacity when the form had no opacity field yet.
             * Skip a≈0 — that is Blend Color intensity off, not invisible opacity. */
            if (!map.has("opacity"))
            {
                BaseValue colorValue = this.get("color");

                if (colorValue instanceof ValueColor valueColor)
                {
                    Color color = valueColor.get().copy();

                    if (color.a > 0.001F && color.a < 0.999F)
                    {
                        this.opacity.set(MathUtils.clamp(color.a, 0F, 1F));
                        color.a = 1F;
                        valueColor.set(color);
                    }
                }
            }
            else
            {
                /* Compatible Int dual-write put opacity into color.a; Opacity owns fade now. */
                BaseValue colorValue = this.get("color");

                if (colorValue instanceof ValueColor valueColor)
                {
                    Color color = valueColor.get().copy();

                    color.a = 0F;
                    valueColor.set(color);
                }
            }
        }
    }

    public float getFormOpacity()
    {
        return MathUtils.clamp(this.opacity.get(), 0F, 1F);
    }

    /**
     * Registers {@code color_overlay} / {@code color_overlayN} tracks. Call from subclasses that
     * expose a Blend Color property so the count matches {@code pose_transform_overlays}.
     */
    protected void registerColorOverlays()
    {
        if (this.colorOverlaysRegistered)
        {
            return;
        }

        this.colorOverlaysRegistered = true;
        this.add(this.colorOverlay);

        for (int i = 0; i < BBSSettings.recordingPoseTransformOverlays.get(); i++)
        {
            ValueColor overlay = new ValueColor("color_overlay" + i, new Color(1F, 1F, 1F, 0F));

            this.additionalColors.add(overlay);
            this.add(overlay);
        }
    }

    /**
     * Ensure {@code transform_overlay} ({@code numberedIndex < 0}) or {@code transform_overlayN}
     * exists for Minecut drag-drop stacking beyond the global recording overlay count.
     */
    public ValueTransform ensureTransformOverlay(int numberedIndex)
    {
        if (numberedIndex < 0)
        {
            return this.transformOverlay;
        }

        while (this.additionalTransforms.size() <= numberedIndex)
        {
            int i = this.additionalTransforms.size();
            ValueTransform valueTransform = new ValueTransform("transform_overlay" + i, new Transform());

            this.additionalTransforms.add(valueTransform);
            this.add(valueTransform);
        }

        return this.additionalTransforms.get(numberedIndex);
    }

    /**
     * Ensure {@code color_overlay} / {@code color_overlayN}. Registers the color-overlay family
     * on demand for forms that did not call {@link #registerColorOverlays()} at construction.
     */
    public ValueColor ensureColorOverlay(int numberedIndex)
    {
        if (!this.colorOverlaysRegistered)
        {
            this.colorOverlaysRegistered = true;
            this.add(this.colorOverlay);
        }

        if (numberedIndex < 0)
        {
            return this.colorOverlay;
        }

        while (this.additionalColors.size() <= numberedIndex)
        {
            int i = this.additionalColors.size();
            ValueColor overlay = new ValueColor("color_overlay" + i, new Color(1F, 1F, 1F, 0F));

            this.additionalColors.add(overlay);
            this.add(overlay);
        }

        return this.additionalColors.get(numberedIndex);
    }

    public ValueIllusion ensureIllusionOverlay(int numberedIndex)
    {
        if (numberedIndex < 0)
        {
            return this.illusionOverlay;
        }

        while (this.additionalIllusions.size() <= numberedIndex)
        {
            int i = this.additionalIllusions.size();
            ValueIllusion valueIllusion = new ValueIllusion("illusion_overlay" + i, new Illusion());

            this.additionalIllusions.add(valueIllusion);
            this.add(valueIllusion);
        }

        return this.additionalIllusions.get(numberedIndex);
    }

    /**
     * Base {@code color} plus stacked color overlays (same idea as transform overlays).
     */
    public Color getFormColor()
    {
        BaseValue property = this.get("color");
        Color base = property instanceof ValueColor valueColor
            ? valueColor.get()
            : new Color(1F, 1F, 1F, 0F);

        return this.composeColorOverlays(base);
    }

    /**
     * Stacks registered color overlays onto {@code base}. Neutral overlays (intensity 0, no
     * grade / mask) are skipped so empty overlay tracks do not change the result.
     */
    public Color composeColorOverlays(Color base)
    {
        Color out = base == null ? new Color(1F, 1F, 1F, 0F) : base.copy();

        if (!this.colorOverlaysRegistered)
        {
            return out;
        }

        this.applyColorOverlay(out, this.colorOverlay.get());

        for (ValueColor overlay : this.additionalColors)
        {
            this.applyColorOverlay(out, overlay.get());
        }

        return out;
    }

    private void applyColorOverlay(Color target, Color overlay)
    {
        if (overlay == null)
        {
            return;
        }

        float intensity = MathUtils.clamp(overlay.a, 0F, 1F);
        boolean hasGrade = overlay.hasColorAdjustments() || overlay.hasActiveGradeTransform();
        boolean hasMask = overlay.hasActiveTransform();

        if (intensity <= 0.001F && !hasGrade && !hasMask)
        {
            return;
        }

        if (intensity > 0.001F)
        {
            target.r = mchorse.bbs_mod.utils.interps.Lerps.lerp(target.r, overlay.r, intensity);
            target.g = mchorse.bbs_mod.utils.interps.Lerps.lerp(target.g, overlay.g, intensity);
            target.b = mchorse.bbs_mod.utils.interps.Lerps.lerp(target.b, overlay.b, intensity);
            target.a = MathUtils.clamp(target.a + intensity * (1F - target.a), 0F, 1F);
        }

        if (hasMask)
        {
            target.transform = overlay.transform.copy();
        }

        if (hasGrade)
        {
            target.brightness = overlay.brightness;
            target.contrast = overlay.contrast;
            target.hue = overlay.hue;
            target.saturation = overlay.saturation;
            target.brightnessTransform = overlay.brightnessTransform == null ? null : overlay.brightnessTransform.copy();
            target.contrastTransform = overlay.contrastTransform == null ? null : overlay.contrastTransform.copy();
            target.hueTransform = overlay.hueTransform == null ? null : overlay.hueTransform.copy();
            target.saturationTransform = overlay.saturationTransform == null ? null : overlay.saturationTransform.copy();
        }
    }

    /**
     * Multiplies {@code color.a} by the Opacity track. Blend Color stores tint strength in
     * {@code color.a}; call {@link Color#applyBlendIntensity()} first so RGB is resolved and
     * opacity stays independent.
     */
    public void applyFormOpacity(Color color)
    {
        if (color == null)
        {
            return;
        }

        color.a = MathUtils.clamp(color.a * this.getFormOpacity(), 0F, 1F);
    }

    @Override
    public BaseType toData()
    {
        BaseType data = super.toData();

        if (data instanceof MapType map)
        {
            BBSMod.getForms().appendId(this, map);

            if (BBSSettings.isSaveAsCompatible())
            {
                this.dualWriteOpacityIntoColor(map);
            }
        }

        return data;
    }

    /**
     * Older builds fade via {@code color.a} only. Write Int ARGB for them, and keep the
     * modern Color map (grade / blend intensity / transforms) in {@code color_bbs}.
     */
    private void dualWriteOpacityIntoColor(MapType map)
    {
        float opacityA = MathUtils.clamp(this.opacity.get(), 0F, 1F);

        if (opacityA > 0.999F)
        {
            return;
        }

        BaseValue colorValue = this.get("color");

        if (!(colorValue instanceof ValueColor valueColor))
        {
            return;
        }

        Color source = valueColor.get().copy();
        BaseType modernData = KeyframeFactories.COLOR.toData(source);

        if (modernData instanceof MapType modernMap)
        {
            modernMap.putFloat(mchorse.bbs_mod.utils.keyframes.factories.ColorKeyframeFactory.BLEND_A, source.a);
            map.put("color_bbs", modernMap);
        }

        map.put("color", new IntType(Colors.setA(source.getRGBColor(), opacityA)));
    }

    /**
     * Older builds defaulted {@code render_depth_enabled} to true and saved it on every morph.
     * Remove that baked-on flag when depth was never customized so the feature stays off by default.
     */
    private void stripLegacyDefaultRenderDepthEnabled(MapType map)
    {
        if (!map.has("render_depth_enabled"))
        {
            return;
        }

        boolean enabled = map.getBool("render_depth_enabled");
        float depth = map.has("render_depth") ? map.getFloat("render_depth") : 0F;

        if (enabled && Math.abs(depth) < 0.0001F)
        {
            map.remove("render_depth_enabled");
        }
    }
}