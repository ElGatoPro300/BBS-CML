package mchorse.bbs_mod.cubic.animation;

import mchorse.bbs_mod.bobj.BOBJBone;
import mchorse.bbs_mod.cubic.IModel;
import mchorse.bbs_mod.cubic.IModelInstance;
import mchorse.bbs_mod.cubic.animation.gecko.config.GeckoAnimationsConfig;
import mchorse.bbs_mod.cubic.animation.gecko.controllers.GeckoAnimationController;
import mchorse.bbs_mod.cubic.animation.gecko.model.GeckoAnimationContext;
import mchorse.bbs_mod.cubic.animation.gecko.routes.GeckoAnimationRouteRegistry;
import mchorse.bbs_mod.cubic.animation.gecko.routes.GeckoLimbRole;
import mchorse.bbs_mod.cubic.animation.gecko.services.GeckoAnimationBlendService;
import mchorse.bbs_mod.cubic.animation.gecko.services.GeckoAnimationEventBus;
import mchorse.bbs_mod.cubic.animation.gecko.services.GeckoAnimationService;
import mchorse.bbs_mod.cubic.animation.gecko.services.GeckoBOBJLimbService;
import mchorse.bbs_mod.cubic.animation.gecko.services.GeckoModelLimbService;
import mchorse.bbs_mod.cubic.data.animation.Animation;
import mchorse.bbs_mod.cubic.data.animation.Animations;
import mchorse.bbs_mod.cubic.data.model.Model;
import mchorse.bbs_mod.cubic.data.model.ModelGroup;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.entities.StubEntity;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.interps.Lerps;
import mchorse.bbs_mod.utils.pose.Pose;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ProceduralAnimator implements IAnimator
{
    public ActionPlayback basePre;
    public ActionPlayback basePost;
    public ActionPlayback riding;
    public ActionPlayback ridingIdle;

    private IModelInstance model;
    private GeckoAnimationsConfig geckoAnimations = new GeckoAnimationsConfig();
    private final GeckoAnimationController geckoController = new GeckoAnimationController(
        new GeckoAnimationService(
            new GeckoAnimationRouteRegistry(),
            new GeckoModelLimbService(),
            new GeckoBOBJLimbService(),
            new GeckoAnimationBlendService(),
            new GeckoAnimationEventBus()
        )
    );

    @Override
    public List<String> getActions()
    {
        return Arrays.asList("base_pre", "base_post");
    }

    @Override
    public void setup(IModelInstance model, ActionsConfig actions, boolean fade)
    {
        this.model = model;
        ActionsConfig safeActions = actions == null ? new ActionsConfig() : actions;
        this.geckoAnimations = safeActions.geckoAnimations;

        this.basePre = this.createAction(this.basePre, safeActions.getConfig("base_pre"), true);
        this.basePost = this.createAction(this.basePost, safeActions.getConfig("base_post"), true);
        this.riding = this.createAction(this.riding, safeActions.getConfig("riding"), true);
        this.ridingIdle = this.createAction(this.ridingIdle, safeActions.getConfig("riding_idle"), true);
    }

    /**
     * Create an action with default priority
     */
    public ActionPlayback createAction(ActionPlayback old, ActionConfig config, boolean looping)
    {
        return this.createAction(old, config, looping, 1);
    }

    /**
     * Create an action playback based on given arguments. This method
     * is used for creating actions so it was easier to tell which
     * actions are missing. Besides that, you can pass an old action so
     * in form merging situation it wouldn't interrupt animation.
     */
    public ActionPlayback createAction(ActionPlayback old, ActionConfig config, boolean looping, int priority)
    {
        Animations animations = this.model == null ? null : this.model.getAnimations();

        if (animations == null)
        {
            return null;
        }

        Animation action = animations.get(config.name);

        /* If given action is missing, then omit creation of ActionPlayback */
        if (action == null)
        {
            return null;
        }

        /* If old is the same, then there is no point creating a new one */
        if (old != null && old.action == action)
        {
            old.config = config;
            old.setSpeed(1);

            return old;
        }

        return new ActionPlayback(action, config, looping, priority);
    }

    @Override
    public void update(IEntity entity)
    {
        /* Update primary actions */
        if (this.basePre != null)
        {
            this.basePre.update();
        }

        if (this.basePost != null)
        {
            this.basePost.update();
        }
    }

    @Override
    public void applyActions(IEntity target, IModelInstance armature, float transition)
    {
        if (target == null)
        {
            return;
        }

        if (this.basePre != null)
        {
            this.basePre.apply(target, armature.getModel(), transition, 1F, false);
        }

        IModel model = armature.getModel();
        class_1799 main = target.getEquipmentStack(class_1304.field_6173);
        class_1799 offhand = target.getEquipmentStack(class_1304.field_6171);

        boolean isRolling = target.getRoll() > 4;
        boolean isInSwimmingPose = target.getEntityPose() == class_4050.field_18079;

        /* Common variables */
        float handSwingProgress = target.getHandSwingProgress(transition);
        float age = target.getAge() + transition;
        float bodyYaw = (float) Lerps.lerpYaw(target.getPrevBodyYaw(), target.getBodyYaw(), transition);
        float headYaw = (float) Lerps.lerpYaw(target.getPrevHeadYaw(), target.getHeadYaw(), transition);
        float yaw = headYaw - bodyYaw;
        float pitch = (float) Lerps.lerp(target.getPrevPitch(), target.getPitch(), transition);
        float limbSpeed = target.getLimbSpeed(transition);
        float limbPhase = target.getLimbPos(transition);
        class_243 entityVelocity = target.getVelocity();
        double dx = target.getX() - target.getPrevX();
        double dz = target.getZ() - target.getPrevZ();
        float velocityHorizontalSpeed = (float) Math.sqrt(entityVelocity.field_1352 * entityVelocity.field_1352 + entityVelocity.field_1350 * entityVelocity.field_1350) * 20F;
        float displacementHorizontalSpeed = (float) Math.sqrt(dx * dx + dz * dz) * 20F;
        float horizontalSpeed = Math.max(velocityHorizontalSpeed, displacementHorizontalSpeed);
        float bodyYawRad = MathUtils.toRad(bodyYaw);
        float forwardX = -class_3532.method_15374(bodyYawRad);
        float forwardZ = class_3532.method_15362(bodyYawRad);
        float velocityForwardSpeed = ((float) entityVelocity.field_1352 * forwardX + (float) entityVelocity.field_1350 * forwardZ) * 20F;
        float displacementForwardSpeed = ((float) dx * forwardX + (float) dz * forwardZ) * 20F;
        float forwardSpeed = Math.abs(velocityForwardSpeed) >= Math.abs(displacementForwardSpeed) ? velocityForwardSpeed : displacementForwardSpeed;

        if (target.isRiding() || target.isSitting())
        {
            limbSpeed = 0F;
            horizontalSpeed = 0F;
            forwardSpeed = 0F;
        }

        boolean riding = target.isRiding() || target.isSitting();
        boolean isMainHandBlocking = target.getActiveHand() == class_1268.field_5808;
        Map<GeckoLimbRole, String> roleBones = ProceduralPoseDefaults.buildRoleBoneMap(model);
        String rightArmBone = this.roleBone(roleBones, GeckoLimbRole.RIGHT_ARM, "right_arm");
        String leftArmBone = this.roleBone(roleBones, GeckoLimbRole.LEFT_ARM, "left_arm");
        String rightLegBone = this.roleBone(roleBones, GeckoLimbRole.RIGHT_LEG, "right_leg");
        String leftLegBone = this.roleBone(roleBones, GeckoLimbRole.LEFT_LEG, "left_leg");
        String torsoBone = this.roleBone(roleBones, GeckoLimbRole.TORSO, "torso");

        float leaningPitch = target.getLeaningPitch(transition);
        String headBone = armature.getHeadBone();

        float coefficient = 1F;

        if (isRolling)
        {
            coefficient = (float) (target.getVelocity().method_1027() / 2D);
            coefficient = Math.min(1F, coefficient * coefficient * coefficient);
        }

        model.resetPose();

        if (riding)
        {
            this.applyRidingPoseOrAnimation(target, armature, model, transition);
        }
        else if (target.isSneaking())
        {
            model.applyPose(armature.getSneakingPose());
        }

        /* For regular models */
        if (model instanceof Model)
        {
            ModelGroup leftArm = null;
            ModelGroup rightArm = null;
            ModelGroup torso = null;

            for (ModelGroup group : model.getAllGroups())
            {
                if (group.id.equals("anchor"))
                {
                    if (target.isSleeping())
                    {
                        group.current.rotate.x = 90.0F;
                        group.current.translate.y -= 14F;
                    }
                    else if (target.isUsingRiptide())
                    {
                        group.current.rotate.x = -90.0F - pitch;
                        group.current.rotate2.y = age * -75.0F;
                    }
                    else if (target.isFallFlying())
                    {
                        group.current.rotate.x = -90.0F - pitch;
                        group.current.rotate.y = 0F;
                        group.current.rotate.z = 0F;
                    }
                    else if (target.isCrawling())
                    {
                        group.current.rotate.x = -90.0F - pitch;
                        group.current.translate.y -= 0.5F * 16F;
                        group.current.translate.z += 0.3F * 16F;
                    }
                    else if (leaningPitch > 0F || target.isSwimming())
                    {
                        float newPitch = target.isTouchingWater() ? -90F - pitch : -90F;

                        group.current.rotate.x = class_3532.method_16439(leaningPitch > 0F ? leaningPitch : 1F, 0F, newPitch);

                        if (target.getEntityPose() == class_4050.field_18079 || target.isSwimming())
                        {
                            group.current.translate.y -= 0.5F * 16F;
                            group.current.translate.z += 0.3F * 16F;
                        }
                    }
                }
                else if (group.id.equals(headBone))
                {
                    group.current.rotate.y = -yaw;

                    if (isRolling)
                    {
                        group.current.rotate.x = 45;
                    }
                    else if (leaningPitch > 0F)
                    {
                        group.current.rotate.x = this.lerpAngle(leaningPitch, group.current.rotate.x, isInSwimmingPose ? 45 : -pitch);
                    }
                    else
                    {
                        group.current.rotate.x = -pitch;
                    }
                }
                else if (group.id.equals(rightArmBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            group.current.rotate.x = 0F;
                            group.current.rotate.y = 0F;
                            group.current.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.12F + limbPhase * 0.2F;
                            float strokePhase = (float) (Math.sin(swimProgress) * 0.5F + 0.5F);
                            float armPitch = 180F - strokePhase * 90F;
                            float armSweep = strokePhase * 90F;

                            group.current.rotate.x = armPitch;
                            group.current.rotate.y = -armSweep;
                            group.current.rotate.z = 0F;
                        }
                        else if (target.isBlocking() && isMainHandBlocking)
                        {
                            group.current.rotate.x = 45F;
                            group.current.rotate.y = 25F;
                            group.current.rotate.z = 15F;
                        }
                        else
                        {
                            group.current.rotate.x += MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F) * 2.0F * limbSpeed * 0.5F / coefficient);
                            group.current.rotate.z += MathUtils.toDeg(1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F));
                            group.current.rotate.x += MathUtils.toDeg(1F * class_3532.method_15374(-age * 0.067F) * 0.05F);

                            if (!main.method_7960())
                            {
                                group.current.rotate.x = group.current.rotate.x * 0.5F + 18F;
                            }
                        }
                    }

                    rightArm = group;
                }
                else if (group.id.equals(leftArmBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            group.current.rotate.x = 0F;
                            group.current.rotate.y = 0F;
                            group.current.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.12F + limbPhase * 0.2F;
                            float strokePhase = (float) (Math.sin(swimProgress) * 0.5F + 0.5F);
                            float armPitch = 180F - strokePhase * 90F;
                            float armSweep = strokePhase * 90F;

                            group.current.rotate.x = armPitch;
                            group.current.rotate.y = armSweep;
                            group.current.rotate.z = 0F;
                        }
                        else if (target.isBlocking() && !isMainHandBlocking)
                        {
                            group.current.rotate.x = 45F;
                            group.current.rotate.y = -25F;
                            group.current.rotate.z = -15F;
                        }
                        else
                        {
                            group.current.rotate.x += MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 2.0F * limbSpeed * 0.5F / coefficient);
                            group.current.rotate.z += MathUtils.toDeg(-1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F));
                            group.current.rotate.x += MathUtils.toDeg(-1F * class_3532.method_15374(-age * 0.067F) * 0.05F);

                            if (!offhand.method_7960())
                            {
                                group.current.rotate.x = group.current.rotate.x * 0.5F + 18F;
                            }
                        }
                    }

                    leftArm = group;
                }
                else if (group.id.equals(torsoBone))
                {
                    torso = group;
                }
                else if (group.id.equals(rightLegBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            group.current.rotate.x = 0F;
                            group.current.rotate.y = 0F;
                            group.current.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.15F + limbPhase * 0.2F;
                            group.current.rotate.x = (float) Math.cos(swimProgress * 0.5F) * 18F;
                            group.current.rotate.y = 0F;
                            group.current.rotate.z = 0F;
                        }
                        else
                        {
                            group.current.rotate.x = MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 1.4F * limbSpeed / coefficient);
                        }
                    }
                }
                else if (group.id.equals(leftLegBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            group.current.rotate.x = 0F;
                            group.current.rotate.y = 0F;
                            group.current.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.15F + limbPhase * 0.2F;
                            group.current.rotate.x = -(float) Math.cos(swimProgress * 0.5F) * 18F;
                            group.current.rotate.y = 0F;
                            group.current.rotate.z = 0F;
                        }
                        else
                        {
                            group.current.rotate.x = MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F) * 1.4F * limbSpeed / coefficient);
                        }
                    }
                }
            }

            if (!riding && handSwingProgress > 0F && torso != null && leftArm != null && rightArm != null)
            {
                ModelGroup group;
                float swingFactor = handSwingProgress;

                torso.current.rotate.y = -MathUtils.toDeg(class_3532.method_15374(class_3532.method_15355(swingFactor) * MathUtils.PI * 2F) * 0.2F);

                leftArm.current.translate.z += (float) Math.sin(MathUtils.toRad(torso.current.rotate.y)) * 5F;
                leftArm.current.translate.x += (float) Math.cos(MathUtils.toRad(torso.current.rotate.y)) * 5F - 5F;
                rightArm.current.translate.z -= (float) Math.sin(MathUtils.toRad(torso.current.rotate.y)) * 5F;
                rightArm.current.translate.x -= (float) Math.cos(MathUtils.toRad(torso.current.rotate.y)) * 5F - 5F;

                group = rightArm;
                group.current.rotate.y += torso.current.rotate.y;
                group = leftArm;
                group.current.rotate.y += torso.current.rotate.y;
                group = leftArm;
                group.current.rotate.x += torso.current.rotate.y;

                swingFactor = 1F - handSwingProgress;
                swingFactor *= swingFactor;
                swingFactor *= swingFactor;
                swingFactor = 1F - swingFactor;

                float headPitch = 0F;
                float swing1 = class_3532.method_15374(swingFactor * MathUtils.PI);
                float swign2 = class_3532.method_15374(handSwingProgress * MathUtils.PI) * -(headPitch - 0.7F) * 0.75F;
                rightArm.current.rotate.x = group.current.rotate.x + MathUtils.toDeg(swing1 * 1.2F + swign2);
                rightArm.current.rotate.y += torso.current.rotate.y * 2F;
                rightArm.current.rotate.z += MathUtils.toDeg(class_3532.method_15374(handSwingProgress * MathUtils.PI) * -0.4F);
            }
        }
        /* For BOBJ models */
        else
        {
            BOBJBone bobjLeftArm = null;
            BOBJBone bobjRightArm = null;

            for (BOBJBone bone : model.getAllBOBJBones())
            {
                if (bone.name.equals("anchor"))
                {
                    if (target.isSleeping())
                    {
                        bone.transform.rotate.x = MathUtils.toRad(90.0F);
                        bone.transform.translate.y -= MathUtils.toRad(14F);
                    }
                    else if (target.isUsingRiptide())
                    {
                        bone.transform.rotate.x = MathUtils.toRad(-90.0F - pitch);
                        bone.transform.rotate2.y = MathUtils.toRad(age * -75.0F);
                    }
                    else if (target.isFallFlying())
                    {
                        bone.transform.rotate.x = MathUtils.toRad(-90.0F - pitch);
                        bone.transform.rotate.y = 0F;
                        bone.transform.rotate.z = 0F;
                    }
                    else if (target.isCrawling())
                    {
                        bone.transform.rotate.x = MathUtils.toRad(-90.0F - pitch);
                        bone.transform.translate.y -= MathUtils.toRad(0.5F * 16F);
                        bone.transform.translate.z += MathUtils.toRad(0.3F * 16F);
                    }
                    else if (leaningPitch > 0F || target.isSwimming())
                    {
                        float newPitch = target.isTouchingWater() ? -90F - pitch : -90F;

                        bone.transform.rotate.x = MathUtils.toRad(class_3532.method_16439(leaningPitch > 0F ? leaningPitch : 1F, 0F, newPitch));

                        if (target.getEntityPose() == class_4050.field_18079 || target.isSwimming())
                        {
                            bone.transform.translate.y -= MathUtils.toRad(0.5F * 16F);
                            bone.transform.translate.z += MathUtils.toRad(0.3F * 16F);
                        }
                    }
                }
                else if (bone.name.equals(headBone))
                {
                    bone.transform.rotate.y = MathUtils.toRad(-yaw);

                    if (isRolling)
                    {
                        bone.transform.rotate.x = -MathUtils.toRad(45);
                    }
                    else if (leaningPitch > 0F)
                    {
                        bone.transform.rotate.x = -MathUtils.toRad(this.lerpAngle(leaningPitch, bone.transform.rotate.x, isInSwimmingPose ? 45 : -pitch));
                    }
                    else
                    {
                        bone.transform.rotate.x = -MathUtils.toRad(-pitch);
                    }
                }
                else if (bone.name.equals(rightArmBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            bone.transform.rotate.x = 0F;
                            bone.transform.rotate.y = 0F;
                            bone.transform.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.12F + limbPhase * 0.2F;
                            float strokePhase = (float) (Math.sin(swimProgress) * 0.5F + 0.5F);
                            float armPitch = 180F - strokePhase * 90F;
                            float armSweep = strokePhase * 90F;

                            bone.transform.rotate.x = MathUtils.toRad(armPitch);
                            bone.transform.rotate.y = -MathUtils.toRad(armSweep);
                            bone.transform.rotate.z = 0F;
                        }
                        else if (target.isBlocking() && isMainHandBlocking)
                        {
                            bone.transform.rotate.x = MathUtils.toRad(45F);
                            bone.transform.rotate.y = MathUtils.toRad(25F);
                            bone.transform.rotate.z = MathUtils.toRad(15F);
                        }
                        else
                        {
                            bone.transform.rotate.x += class_3532.method_15362(limbPhase * 0.6662F) * 2.0F * limbSpeed * 0.5F / coefficient;
                            bone.transform.rotate.z -= 1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F);
                            bone.transform.rotate.x += 1F * class_3532.method_15374(-age * 0.067F) * 0.05F;

                            if (!main.method_7960())
                            {
                                bone.transform.rotate.x = bone.transform.rotate.x * 0.5F + MathUtils.toRad(18F);
                            }
                        }
                    }

                    bobjRightArm = bone;
                }
                else if (bone.name.equals(leftArmBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            bone.transform.rotate.x = 0F;
                            bone.transform.rotate.y = 0F;
                            bone.transform.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.12F + limbPhase * 0.2F;
                            float strokePhase = (float) (Math.sin(swimProgress) * 0.5F + 0.5F);
                            float armPitch = 180F - strokePhase * 90F;
                            float armSweep = strokePhase * 90F;

                            bone.transform.rotate.x = MathUtils.toRad(armPitch);
                            bone.transform.rotate.y = MathUtils.toRad(armSweep);
                            bone.transform.rotate.z = 0F;
                        }
                        else if (target.isBlocking() && !isMainHandBlocking)
                        {
                            bone.transform.rotate.x = MathUtils.toRad(45F);
                            bone.transform.rotate.y = -MathUtils.toRad(25F);
                            bone.transform.rotate.z = -MathUtils.toRad(15F);
                        }
                        else
                        {
                            bone.transform.rotate.x += class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 2.0F * limbSpeed * 0.5F / coefficient;
                            bone.transform.rotate.z -= -1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F);
                            bone.transform.rotate.x += -1F * class_3532.method_15374(-age * 0.067F) * 0.05F;

                            if (!offhand.method_7960())
                            {
                                bone.transform.rotate.x = bone.transform.rotate.x * 0.5F + MathUtils.toRad(18F);
                            }
                        }
                    }

                    bobjLeftArm = bone;
                }
                else if (bone.name.equals(rightLegBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            bone.transform.rotate.x = 0F;
                            bone.transform.rotate.y = 0F;
                            bone.transform.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.15F + limbPhase * 0.2F;
                            bone.transform.rotate.x = MathUtils.toRad((float) Math.cos(swimProgress * 0.5F) * 18F);
                            bone.transform.rotate.y = 0F;
                            bone.transform.rotate.z = 0F;
                        }
                        else
                        {
                            bone.transform.rotate.x = class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 1.4F * limbSpeed / coefficient;
                        }
                    }
                }
                else if (bone.name.equals(leftLegBone))
                {
                    if (!riding)
                    {
                        if (target.isFallFlying())
                        {
                            bone.transform.rotate.x = 0F;
                            bone.transform.rotate.y = 0F;
                            bone.transform.rotate.z = 0F;
                        }
                        else if (target.isSwimming())
                        {
                            float swimProgress = (age + transition) * 0.15F + limbPhase * 0.2F;
                            bone.transform.rotate.x = -MathUtils.toRad((float) Math.cos(swimProgress * 0.5F) * 18F);
                            bone.transform.rotate.y = 0F;
                            bone.transform.rotate.z = 0F;
                        }
                        else
                        {
                            bone.transform.rotate.x = class_3532.method_15362(limbPhase * 0.6662F) * 1.4F * limbSpeed / coefficient;
                        }
                    }
                }
            }

            if (!riding && handSwingProgress > 0F && bobjLeftArm != null && bobjRightArm != null)
            {
                BOBJBone group;
                float swingFactor = handSwingProgress;
                float rotate = -MathUtils.toDeg(class_3532.method_15374(class_3532.method_15355(swingFactor) * MathUtils.PI * 2F) * 0.2F);

                bobjLeftArm.transform.translate.z -= ((float) Math.sin(MathUtils.toRad(rotate)) * 5F) / 16F;
                bobjLeftArm.transform.translate.x -= ((float) Math.cos(MathUtils.toRad(rotate)) * 5F - 5F) / 16F;
                bobjRightArm.transform.translate.z += ((float) Math.sin(MathUtils.toRad(rotate)) * 5F) / 16F;
                bobjRightArm.transform.translate.x += ((float) Math.cos(MathUtils.toRad(rotate)) * 5F - 5F) / 16F;

                group = bobjRightArm;
                group.transform.rotate.y -= MathUtils.toRad(rotate);
                group = bobjLeftArm;
                group.transform.rotate.y -= MathUtils.toRad(rotate);
                group = bobjLeftArm;
                group.transform.rotate.x += MathUtils.toRad(rotate);

                swingFactor = 1F - handSwingProgress;
                swingFactor *= swingFactor;
                swingFactor *= swingFactor;
                swingFactor = 1F - swingFactor;

                float headPitch = 0F;
                float swing1 = class_3532.method_15374(swingFactor * MathUtils.PI);
                float swign2 = class_3532.method_15374(handSwingProgress * MathUtils.PI) * -(headPitch - 0.7F) * 0.75F;
                bobjRightArm.transform.rotate.x = MathUtils.toRad(group.transform.rotate.x + MathUtils.toDeg(swing1 * 1.2F + swign2));
                bobjRightArm.transform.rotate.y -= MathUtils.toRad(rotate * 2F);
                bobjRightArm.transform.rotate.z -= class_3532.method_15374(handSwingProgress * MathUtils.PI) * -0.4F;
            }
        }

        GeckoAnimationContext geckoContext = new GeckoAnimationContext();
        geckoContext.handSwing = handSwingProgress;
        geckoContext.age = age;
        geckoContext.yaw = yaw;
        geckoContext.pitch = pitch;
        geckoContext.limbSpeed = limbSpeed;
        geckoContext.limbPhase = limbPhase;
        geckoContext.movementCoefficient = coefficient;
        geckoContext.roll = target.getRoll() + transition;
        geckoContext.forwardSpeed = forwardSpeed;
        geckoContext.horizontalSpeed = horizontalSpeed;
        geckoContext.verticalSpeed = (float) entityVelocity.field_1351 * 20F;
        geckoContext.onGround = target.isOnGround();
        geckoContext.sneaking = target.isSneaking();
        geckoContext.riding = target.isRiding() || target.isSitting();
        geckoContext.sprinting = target.isSprinting();
        geckoContext.swimming = target.getEntityPose() == class_4050.field_18079;
        geckoContext.fallFlying = target.isFallFlying();
        geckoContext.usingRiptide = target.isUsingRiptide();
        geckoContext.hasMainHandItem = !main.method_7960();
        geckoContext.hasOffHandItem = !offhand.method_7960();
        geckoContext.preview = target instanceof StubEntity;
        geckoContext.previewWheelSpeed = this.geckoAnimations.previewWheelSpeed;

        this.geckoController.apply(target, model, this.model == null ? null : this.model.getAnimations(), this.geckoAnimations, geckoContext);

        if (this.basePost != null)
        {
            this.basePost.postApply(target, armature.getModel(), transition);
        }
    }

    @Override
    public void playAnimation(String name)
    {}

    private ActionPlayback getRidingAction(IEntity target)
    {
        IEntity mount = target.getMountTarget();
        boolean mountMoves = false;

        if (mount != null)
        {
            double mdx = mount.getX() - mount.getPrevX();
            double mdz = mount.getZ() - mount.getPrevZ();

            mountMoves = Math.abs(mdx) > 0.003D || Math.abs(mdz) > 0.003D;
        }

        if (!mountMoves && this.ridingIdle != null)
        {
            return this.ridingIdle;
        }

        return this.riding;
    }

    private void applyRidingPoseOrAnimation(IEntity target, IModelInstance armature, IModel model, float transition)
    {
        Pose ridingPose = armature.getRidingPose();

        if (ridingPose != null && !ridingPose.isEmpty())
        {
            /* Anchor offset is for pose-editor preview; world position is handled by mount sync */
            Pose applied = ridingPose.copy();
            String anchorBone = model.getAnchor();

            if (anchorBone == null || anchorBone.isEmpty())
            {
                anchorBone = "anchor";
            }

            applied.transforms.remove(anchorBone);
            model.applyPose(applied);

            return;
        }

        ActionPlayback ridingAction = this.getRidingAction(target);

        if (ridingAction == null)
        {
            return;
        }

        ridingAction.update();
        ridingAction.apply(target, model, transition, 1F, false);
    }

    private String roleBone(Map<GeckoLimbRole, String> roleBones, GeckoLimbRole role, String fallback)
    {
        String bone = roleBones.get(role);

        return bone != null ? bone : fallback;
    }

    protected float lerpAngle(float a, float b, float magnitude)
    {
        float factor = (magnitude - b) % (360);

        if (factor < -180) factor += 360;
        if (factor >= 180) factor -= 360;

        return b + a * factor;
    }

}
