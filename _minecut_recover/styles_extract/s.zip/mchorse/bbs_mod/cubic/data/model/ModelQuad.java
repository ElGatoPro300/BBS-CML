package mchorse.bbs_mod.cubic.data.model;

import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

public class ModelQuad
{
    public List<ModelVertex> vertices = new ArrayList<>();
    public Vector3f normal = new Vector3f();

    public ModelQuad normal(float x, float y, float z)
    {
        this.normal.set(x, y, z);

        return this;
    }

    public ModelQuad vertex(float x, float y, float z, float u, float v)
    {
        ModelVertex vertex = new ModelVertex();

        vertex.vertex.set(x, y, z);
        vertex.uv.set(u, v);
        this.vertices.add(vertex);

        return this;
    }

    public ModelQuad copy()
    {
        ModelQuad q = new ModelQuad();
        q.normal.set(this.normal);
        for (ModelVertex v : this.vertices) q.vertices.add(v.copy());
        return q;
    }
}