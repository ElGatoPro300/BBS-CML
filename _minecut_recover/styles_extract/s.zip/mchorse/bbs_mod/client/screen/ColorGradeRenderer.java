package mchorse.bbs_mod.client.screen;

import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.camera.clips.screen.ColorEffect;
import mchorse.bbs_mod.camera.clips.screen.GrainEffect;
import mchorse.bbs_mod.camera.clips.screen.LensDistortionOverscan;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.graphics.texture.TextureFormat;
import mchorse.bbs_mod.ui.framework.elements.utils.Batcher2D;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import com.mojang.blaze3d.systems.RenderSystem;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.util.List;

public class ColorGradeRenderer
{
    private static final String VERT = """
            #version 150

            in vec2 a_pos;
            in vec2 a_uv;
            out vec2 v_uv;

            void main()
            {
                v_uv = a_uv;
                gl_Position = vec4(a_pos, 0.0, 1.0);
            }
            """;

    private static final String FRAG = """
            #version 150

            in vec2 v_uv;
            out vec4 fragColor;

            uniform sampler2D u_sampler;

            /* Vignette */
            uniform float u_vigStr;
            uniform float u_vigSmooth;
            uniform vec3 u_vigColor;

            /* Color grade */
            uniform float u_brightness;
            uniform float u_contrast;
            uniform float u_saturation;
            uniform float u_hue;
            uniform vec3 u_lift;
            uniform vec3 u_gamma;
            uniform vec3 u_gain;

            /* Film grain */
            uniform float u_grainStr;
            uniform float u_grainSize;
            uniform float u_grainSeed;

            /* UV distortion */
            uniform vec2 u_distort;

            /* Cinematic effects */
            uniform float u_aberration;
            uniform float u_vhs;
            uniform float u_lensDistortion;
            uniform float u_lensOverscan;
            uniform float u_vintage;
            uniform float u_radialBlur;
            uniform float u_rain;
            uniform float u_dust;
            uniform float u_lightLeak;
            uniform float u_heatStrength;
            uniform float u_heatSpeed;
            uniform float u_heatScale;
            uniform float u_time;

            /* --- HSL helpers --- */

            vec3 rgb2hsl(vec3 c)
            {
                float maxC = max(c.r, max(c.g, c.b));
                float minC = min(c.r, min(c.g, c.b));
                float delta = maxC - minC;
                float l = (maxC + minC) * 0.5;
                float s = delta < 1e-5 ? 0.0 : delta / (1.0 - abs(2.0 * l - 1.0));
                float h = 0.0;
                if (delta > 1e-5)
                {
                    if      (maxC == c.r) h = mod((c.g - c.b) / delta, 6.0) / 6.0;
                    else if (maxC == c.g) h = ((c.b - c.r) / delta + 2.0) / 6.0;
                    else                  h = ((c.r - c.g) / delta + 4.0) / 6.0;
                }
                return vec3(h, s, l);
            }

            vec3 hsl2rgb(vec3 c)
            {
                float h = c.x, s = c.y, l = c.z;
                float C = (1.0 - abs(2.0 * l - 1.0)) * s;
                float X = C * (1.0 - abs(mod(h * 6.0, 2.0) - 1.0));
                float m = l - C * 0.5;
                vec3 rgb;
                if      (h < 1.0 / 6.0) rgb = vec3(C, X, 0.0);
                else if (h < 2.0 / 6.0) rgb = vec3(X, C, 0.0);
                else if (h < 3.0 / 6.0) rgb = vec3(0.0, C, X);
                else if (h < 4.0 / 6.0) rgb = vec3(0.0, X, C);
                else if (h < 5.0 / 6.0) rgb = vec3(X, 0.0, C);
                else                     rgb = vec3(C, 0.0, X);
                return rgb + m;
            }

            float hash(vec2 p)
            {
                return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
            }

            float heatNoise(vec2 p)
            {
                vec2 i = floor(p);
                vec2 f = fract(p);
                f = f * f * (3.0 - 2.0 * f);

                float a = hash(i);
                float b = hash(i + vec2(1.0, 0.0));
                float c = hash(i + vec2(0.0, 1.0));
                float d = hash(i + vec2(1.0, 1.0));

                return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
            }

            float heatFbm(vec2 p)
            {
                float value = 0.0;
                float amplitude = 0.5;
                float frequency = 1.0;

                for (int i = 0; i < 4; i++)
                {
                    value += amplitude * heatNoise(p * frequency);
                    frequency *= 2.0;
                    amplitude *= 0.5;
                }

                return value;
            }

            void main()
            {
                /* Fisheye on clean UVs so the screen edges map to the wide-FOV image
                 * edges. Distort / VHS are applied after. */
                vec2 distortedUV = v_uv;
                if (abs(u_lensDistortion) > 0.001)
                {
                    vec2 uvOffset = v_uv - vec2(0.5);
                    float r2 = dot(uvOffset, uvOffset);
                    float k = u_lensDistortion;

                    if (k > 0.0 && u_lensOverscan > 1.0)
                    {
                        float s = u_lensOverscan;
                        /* Strongest k that still lands on the FOV-matched edge (no stretch). */
                        float kFit = 2.0 * (s - 1.0);
                        float kUse = min(k, kFit);
                        vec2 warped = uvOffset * (1.0 + kUse * r2);
                        distortedUV = warped / s + vec2(0.5);
                    }
                    else
                    {
                        vec2 warped = uvOffset * (1.0 + k * r2);
                        distortedUV = clamp(warped + vec2(0.5), 0.0, 1.0);
                    }
                }

                vec2 sampleUV = distortedUV + u_distort;

                /* VHS Horizontal Glitch displacement before sampling */
                if (u_vhs > 0.001)
                {
                    float glitchNoise = hash(vec2(floor(sampleUV.y * 80.0), floor(u_time * 12.0)));
                    if (glitchNoise > 0.95 - (u_vhs * 0.05))
                    {
                        sampleUV.x += sin(sampleUV.y * 30.0 + u_time * 10.0) * 0.02 * u_vhs;
                    }
                }

                distortedUV = sampleUV;

                /* Lens Dirt & Rain Overlay (Procedural raindrops and static spots refraction) */
                if (u_rain > 0.001)
                {
                    // Falling rain droplets grid
                    vec2 rainUV = distortedUV * vec2(8.0, 4.5);
                    rainUV.y += u_time * 1.2;
                    vec2 cell = fract(rainUV) - vec2(0.5);
                    vec2 id = floor(rainUV);
                    float dropSeed = hash(id);
                    if (dropSeed > 0.45)
                    {
                        float size = 0.22 * (0.4 + 0.6 * sin(u_time * 1.5 + dropSeed * 6.28));
                        float d = length(cell);
                        if (d < size)
                        {
                            vec2 refractOffset = cell * (size - d) * 1.5;
                            distortedUV += refractOffset * u_rain;
                        }
                    }

                    // Static lens dirt / condensation drops
                    vec2 dirtUV = distortedUV * vec2(12.0, 9.0);
                    vec2 dirtCell = fract(dirtUV) - vec2(0.5);
                    vec2 dirtId = floor(dirtUV);
                    float dirtSeed = hash(dirtId);
                    if (dirtSeed > 0.72)
                    {
                        float d = length(dirtCell);
                        float size = 0.12 * dirtSeed;
                        if (d < size)
                        {
                            distortedUV += dirtCell * (size - d) * 0.4 * u_rain;
                        }
                    }
                }

                /* Heat distortion waves (Mine-imator style) */
                if (u_heatStrength > 0.001)
                {
                    float heatTime = u_time * u_heatSpeed;
                    vec2 distortCoord = distortedUV * u_heatScale + vec2(0.0, heatTime * 0.1);
                    float noiseX = heatFbm(distortCoord + vec2(heatTime * 0.3, 0.0));
                    float noiseY = heatFbm(distortCoord + vec2(0.0, heatTime * 0.2));
                    vec2 heatOffset = (vec2(noiseX, noiseY) * 2.0 - 1.0) * u_heatStrength;
                    distortedUV = clamp(distortedUV + heatOffset, 0.0, 1.0);
                }

                /* Chromatic Aberration splitting */
                vec2 uvRed = distortedUV;
                vec2 uvBlue = distortedUV;
                if (u_aberration > 0.001)
                {
                    vec2 dir = distortedUV - vec2(0.5);
                    float dist = length(dir);
                    vec2 offset = dir * dist * u_aberration;
                    uvRed += offset;
                    uvBlue -= offset;
                    uvRed = clamp(uvRed, 0.0, 1.0);
                    uvBlue = clamp(uvBlue, 0.0, 1.0);
                }

                float r = texture(u_sampler, uvRed).r;
                float g = texture(u_sampler, distortedUV).g;
                float b = texture(u_sampler, uvBlue).b;
                vec3 rgb = vec3(r, g, b);

                /* Radial Action Blur */
                if (u_radialBlur > 0.001)
                {
                    vec2 blurDir = (distortedUV - vec2(0.5)) * u_radialBlur * 0.12;
                    vec3 blurRGB = vec3(0.0);
                    blurRGB += texture(u_sampler, clamp(distortedUV - blurDir * 2.0, 0.0, 1.0)).rgb;
                    blurRGB += texture(u_sampler, clamp(distortedUV - blurDir, 0.0, 1.0)).rgb;
                    blurRGB += rgb;
                    blurRGB += texture(u_sampler, clamp(distortedUV + blurDir, 0.0, 1.0)).rgb;
                    blurRGB += texture(u_sampler, clamp(distortedUV + blurDir * 2.0, 0.0, 1.0)).rgb;
                    rgb = blurRGB / 5.0;
                }

                /* 1 — Lift / Gamma / Gain */
                rgb = rgb * (vec3(1.0) + u_gain);
                rgb = sign(rgb) * pow(max(abs(rgb), vec3(1e-4)), max(vec3(1e-4), vec3(1.0) / (vec3(1.0) + u_gamma)));
                rgb = rgb + u_lift;

                /* 2 — Brightness and contrast */
                rgb = rgb + u_brightness;
                rgb = vec3(0.5) + (1.0 + u_contrast) * (rgb - vec3(0.5));

                /* 3 — Saturation */
                float luma = dot(rgb, vec3(0.2126, 0.7152, 0.0722));
                rgb = mix(vec3(luma), rgb, 1.0 + u_saturation);

                /* 4 — Hue rotation */
                if (abs(u_hue) > 0.01)
                {
                    vec3 hsl = rgb2hsl(rgb);
                    hsl.x = fract(hsl.x + u_hue / 360.0);
                    rgb = hsl2rgb(hsl);
                }

                /* 5 — Vignette (radial, smooth) */
                if (u_vigStr > 0.001)
                {
                    vec2 uv = v_uv - vec2(0.5);
                    float dist = length(uv) * 2.0 / sqrt(2.0);
                    float inner = max(0.0, 1.0 - u_vigSmooth);
                    float alpha = smoothstep(inner, 1.0, dist) * u_vigStr;
                    rgb = mix(rgb, u_vigColor, clamp(alpha, 0.0, 1.0));
                }

                /* 6 — Film grain */
                if (u_grainStr > 0.001)
                {
                    vec2 texSize = vec2(textureSize(u_sampler, 0));
                    vec2 grainUV = floor(v_uv * texSize / max(1.0, u_grainSize));
                    float noise = hash(grainUV + vec2(u_grainSeed));
                    rgb += (noise - 0.5) * u_grainStr * 2.0;
                }

                /* Vintage Film Flicker & Scratches */
                if (u_vintage > 0.001)
                {
                    float flicker = sin(u_time * 73.0) * cos(u_time * 59.0) * 0.07 * u_vintage;
                    rgb += vec3(flicker);

                    float scratchX = hash(vec2(floor(distortedUV.x * 250.0), floor(u_time * 16.0)));
                    if (scratchX > 0.993)
                    {
                        rgb *= mix(1.0, 0.45, u_vintage);
                    }
                }

                /* 7 — VHS Scanlines and Static noise */
                if (u_vhs > 0.001)
                {
                    float scanline = sin(distortedUV.y * 300.0 - u_time * 15.0) * 0.08 * u_vhs;
                    rgb -= vec3(scanline);

                    float vhsNoise = hash(distortedUV + vec2(u_time * 0.01));
                    rgb = mix(rgb, vec3(vhsNoise), 0.03 * u_vhs);
                }

                /* 8 — Cinematic Light Leak Flare */
                if (u_lightLeak > 0.001)
                {
                    float leakGrad = smoothstep(1.2, 0.0, length(distortedUV - vec2(0.0, 0.4)));
                    float leakPulse = 0.65 + 0.35 * sin(u_time * 1.8 + cos(u_time * 1.2));
                    vec3 leakColor = vec3(0.95, 0.48, 0.12) * leakGrad * leakPulse * u_lightLeak;

                    float blueGrad = smoothstep(1.5, 0.0, length(distortedUV - vec2(1.0, 0.7)));
                    vec3 blueColor = vec3(0.12, 0.35, 0.95) * blueGrad * (0.8 + 0.2 * cos(u_time * 0.9)) * u_lightLeak * 0.45;

                    rgb += leakColor + blueColor;
                }

                /* 9 — Projector Dust & Specks (60s tape/projector) */
                if (u_dust > 0.001)
                {
                    float dustTime = floor(u_time * 12.0);

                    for (int i = 0; i < 3; i++)
                    {
                        vec2 randPos = vec2(
                            hash(vec2(dustTime, float(i) * 15.3)),
                            hash(vec2(dustTime, float(i) * 31.7))
                        );

                        float spawnProb = hash(vec2(dustTime, float(i) * 7.9));
                        if (spawnProb < u_dust)
                        {
                            vec2 diff = distortedUV - randPos;
                            diff.x *= 1.77;

                            // Randomly rotate the coordinates for each speck
                            float rotAngle = hash(vec2(dustTime, float(i) * 19.3)) * 6.28318;
                            float cosA = cos(rotAngle);
                            float sinA = sin(rotAngle);
                            vec2 rotatedDiff = vec2(
                                diff.x * cosA - diff.y * sinA,
                                diff.x * sinA + diff.y * cosA
                            );

                            float typeDecider = hash(vec2(dustTime, float(i) * 88.1));

                            if (typeDecider < 0.33)
                            {
                                // Type A: Rounded / Irregular Speck (soot flake)
                                float angle = atan(rotatedDiff.y, rotatedDiff.x);
                                float deform = 1.0 + 0.4 * sin(angle * 4.0) + 0.3 * cos(angle * 7.0 + 0.8);
                                float rLimit = 0.008 * u_dust * deform;
                                if (length(rotatedDiff) < rLimit)
                                {
                                    rgb = mix(rgb, vec3(1.0), 0.95);
                                }
                            }
                            else if (typeDecider < 0.66)
                            {
                                // Type B: Thread / Curved Lint Hair
                                float hairLength = 0.022 * u_dust;
                                float hairThickness = 0.0010 * u_dust;
                                float bend = sin(rotatedDiff.x * 180.0) * 0.005;
                                if (abs(rotatedDiff.x) < hairLength && abs(rotatedDiff.y - bend) < hairThickness)
                                {
                                    rgb = mix(rgb, vec3(1.0), 0.95);
                                }
                            }
                            else
                            {
                                // Type C: Deformed Elongated Ellipse Speck (dust fiber clump)
                                vec2 stretched = vec2(rotatedDiff.x * 2.8, rotatedDiff.y);
                                float angle = atan(stretched.y, stretched.x);
                                float deform = 1.0 + 0.35 * sin(angle * 3.0);
                                float rLimit = 0.012 * u_dust * deform;
                                if (length(stretched) < rLimit)
                                {
                                    rgb = mix(rgb, vec3(1.0), 0.95);
                                }
                            }
                        }
                    }
                }

                fragColor = vec4(clamp(rgb, 0.0, 1.0), texture(u_sampler, distortedUV).a);
            }
            """;

    private static final int SHADER_VERSION = 9;
    private static int loadedShaderVersion;
    private static boolean initialized;
    private static boolean failed;
    private static int program;
    private static int vao;
    private static int vbo;
    private static Texture tempTex;

    private static int uSampler;
    private static int uVigStr;
    private static int uVigSmooth;
    private static int uVigColor;
    private static int uBrightness;
    private static int uContrast;
    private static int uSaturation;
    private static int uHue;
    private static int uLift;
    private static int uGamma;
    private static int uGain;
    private static int uGrainStr;
    private static int uGrainSize;
    private static int uGrainSeed;
    private static int uDistort;
    private static int uAberration;
    private static int uVHS;
    private static int uLensDistortion;
    private static int uLensOverscan;
    private static int uVintage;
    private static int uRadialBlur;
    private static int uRain;
    private static int uDust;
    private static int uLightLeak;
    private static int uHeatStrength;
    private static int uHeatSpeed;
    private static int uHeatScale;
    private static int uTime;

    public static void apply(List<ColorEffect> effects, List<GrainEffect> grainEffects)
    {
        boolean needVignette = false;
        boolean needGrade = false;
        boolean needGrain = false;
        boolean needDistort = false;
        boolean needCinematic = false;

        for (ColorEffect e : effects)
        {
            if (e.hasVignette) needVignette = true;
            if (e.hasGrade) needGrade = true;
            if (e.hasDistort) needDistort = true;
            if (e.hasCinematic) needCinematic = true;
        }

        for (GrainEffect e : grainEffects)
        {
            if (e.strength > 0F) needGrain = true;
        }

        if (!needVignette && !needGrade && !needGrain && !needDistort && !needCinematic)
        {
            return;
        }

        if (!initialized || loadedShaderVersion != SHADER_VERSION)
        {
            if (program != 0)
            {
                GL20.glDeleteProgram(program);
                program = 0;
            }

            failed = false;
            init();
            loadedShaderVersion = SHADER_VERSION;
        }

        if (failed)
        {
            return;
        }

        class_310 mc = class_310.method_1551();
        net.minecraft.class_276 fb = mc.method_1522();
        int fbW = fb.field_1482;
        int fbH = fb.field_1481;

        /* Copy current framebuffer content to tempTex */
        if (tempTex == null)
        {
            tempTex = new Texture();
            tempTex.setFormat(TextureFormat.RGB_U8);
            tempTex.setFilter(GL11.GL_LINEAR);
        }

        fb.method_35610();
        tempTex.bind();

        if (tempTex.width != fbW || tempTex.height != fbH)
        {
            tempTex.setSize(fbW, fbH);
        }

        GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, 0, 0, fbW, fbH);
        tempTex.unbind();
        fb.method_1235(false);

        /* Accumulate color effects */
        float vigStr = 0F;
        float vigSmooth = 0.5F;
        float vigR = 0F;
        float vigG = 0F;
        float vigB = 0F;
        float brightness = 0F;
        float contrast = 0F;
        float saturation = 0F;
        float hue = 0F;
        float liftR = 0F, liftG = 0F, liftB = 0F;
        float gammaR = 0F, gammaG = 0F, gammaB = 0F;
        float gainR = 0F, gainG = 0F, gainB = 0F;

        for (ColorEffect e : effects)
        {
            if (e.hasVignette)
            {
                vigStr = Math.max(vigStr, e.vignetteStrength);
                vigSmooth = e.vignetteSmoothness;
                vigR = ((e.vignetteColor >> 16) & 0xFF) / 255.0F;
                vigG = ((e.vignetteColor >> 8) & 0xFF) / 255.0F;
                vigB = (e.vignetteColor & 0xFF) / 255.0F;
            }

            if (e.hasGrade)
            {
                brightness += e.brightness;
                contrast += e.contrast;
                saturation += e.saturation;
                hue += e.hue;
                liftR += e.liftR;
                liftG += e.liftG;
                liftB += e.liftB;
                gammaR += e.gammaR;
                gammaG += e.gammaG;
                gammaB += e.gammaB;
                gainR += e.gainR;
                gainG += e.gainG;
                gainB += e.gainB;
            }
        }

        /* Accumulate grain effects */
        float grainStr = 0F;
        float grainSize = 1F;

        for (GrainEffect e : grainEffects)
        {
            grainStr += e.strength;
            grainSize = e.size;
        }

        float grainSeed = (System.nanoTime() & 0xFFFFL) / 65536.0F;

        /* Accumulate distortion */
        float distortX = 0F;
        float distortY = 0F;

        for (ColorEffect e : effects)
        {
            if (e.hasDistort)
            {
                distortX += e.distortX;
                distortY += e.distortY;
            }
        }

        /* Accumulate cinematic effects */
        float aberration = 0F;
        float vhs = 0F;
        float lensDistortion = 0F;
        float lensOverscan = 1F;
        float vintage = 0F;
        float radialBlur = 0F;
        float rain = 0F;
        float dust = 0F;
        float lightLeak = 0F;
        float heatStrength = 0F;
        float heatSpeed = 0F;
        float heatScale = 0F;
        float time = 0F;

        for (ColorEffect e : effects)
        {
            if (e.hasCinematic)
            {
                aberration = Math.max(aberration, e.aberration);
                vhs = Math.max(vhs, e.vhs);
                lensDistortion += e.lensDistortion;
                lensOverscan = Math.max(lensOverscan, e.lensOverscan);
                vintage = Math.max(vintage, e.vintage);
                radialBlur = Math.max(radialBlur, e.radialBlur);
                rain = Math.max(rain, e.rain);
                dust = Math.max(dust, e.dust);
                lightLeak = Math.max(lightLeak, e.lightLeak);
                heatStrength = Math.max(heatStrength, e.heatStrength);
                heatSpeed = Math.max(heatSpeed, e.heatSpeed);
                heatScale = Math.max(heatScale, e.heatScale);
                time = e.time;
            }
        }

        /* Save and set viewport */
        int[] prevViewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, prevViewport);
        GL11.glViewport(0, 0, fbW, fbH);

        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_BLEND);

        GL20.glUseProgram(program);

        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        tempTex.bind();
        GL20.glUniform1i(uSampler, 0);

        GL20.glUniform1f(uVigStr, vigStr);
        GL20.glUniform1f(uVigSmooth, vigSmooth);
        GL20.glUniform3f(uVigColor, vigR, vigG, vigB);
        GL20.glUniform1f(uBrightness, brightness);
        GL20.glUniform1f(uContrast, contrast);
        GL20.glUniform1f(uSaturation, saturation);
        GL20.glUniform1f(uHue, hue);
        GL20.glUniform3f(uLift, liftR, liftG, liftB);
        GL20.glUniform3f(uGamma, gammaR, gammaG, gammaB);
        GL20.glUniform3f(uGain, gainR, gainG, gainB);
        GL20.glUniform1f(uGrainStr, grainStr);
        GL20.glUniform1f(uGrainSize, grainSize);
        GL20.glUniform1f(uGrainSeed, grainSeed);
        GL20.glUniform2f(uDistort, distortX, distortY);
        GL20.glUniform1f(uAberration, aberration);
        GL20.glUniform1f(uVHS, vhs);
        /* Use the scale actually applied to this frame's camera FOV. */
        if (lensDistortion > 0F && BBSSettings.editorFisheyeWidenFov != null && BBSSettings.editorFisheyeWidenFov.get())
        {
            float rendered = BBSRendering.getLensOverscanScale();

            if (rendered > 1.0001F)
            {
                lensOverscan = rendered;
            }
            else
            {
                lensOverscan = Math.max(lensOverscan, LensDistortionOverscan.overscanScale(lensDistortion));
            }
        }
        else
        {
            lensOverscan = 1F;
        }

        GL20.glUniform1f(uLensDistortion, lensDistortion);
        GL20.glUniform1f(uLensOverscan, lensOverscan);
        GL20.glUniform1f(uVintage, vintage);
        GL20.glUniform1f(uRadialBlur, radialBlur);
        GL20.glUniform1f(uRain, rain);
        GL20.glUniform1f(uDust, dust);
        GL20.glUniform1f(uLightLeak, lightLeak);
        GL20.glUniform1f(uHeatStrength, heatStrength * 0.006F);
        GL20.glUniform1f(uHeatSpeed, 0.5F + heatSpeed * 2.0F);
        GL20.glUniform1f(uHeatScale, 2.0F + heatScale * 35.0F);
        GL20.glUniform1f(uTime, time);

        GL30.glBindVertexArray(vao);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
        GL30.glBindVertexArray(0);

        GL20.glUseProgram(0);
        tempTex.unbind();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
        fb.method_1235(false);
    }

    /**
     * ColorGrade binds shaders/textures via raw GL, which desyncs {@link RenderSystem}'s
     * tracker (GL may have texture 0 while RenderSystem still thinks a previous id is bound).
     * Subtitle text then skips rebinding the font atlas and bakes a black atlas.
     * <p>
     * Image / Hotbar / a second Subtitle only appear to "fix" this because they issue a
     * {@code PositionTexColor} draw first. Emulate that with an invisible textured pixel.
     */
    public static void resyncMinecraftState(Batcher2D batcher)
    {
        if (batcher == null)
        {
            return;
        }

        class_310 mc = class_310.method_1551();

        mc.method_1522().method_1235(false);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);

        /*
         * Invalidate unit 0 so the following textured draw must call glBindTexture.
         * A PositionColor-only box is not enough — text needs a live Sampler0 bind path.
         */
        RenderSystem.setShaderTexture(0, 0);

        class_1044 atlas = mc.method_1531().method_4619(class_2960.method_60655("minecraft", "textures/atlas/blocks.png"));
        int textureId = atlas == null ? 0 : atlas.method_4624();

        if (textureId != 0)
        {
            /* Fully transparent 1x1 — no visible flash, forces drawWithGlobalProgram. */
            batcher.texturedBox(textureId, 0x00000000, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1);
        }
    }

    private static void init()
    {
        initialized = true;

        int vert = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        GL20.glShaderSource(vert, VERT);
        GL20.glCompileShader(vert);

        if (GL20.glGetShaderi(vert, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE)
        {
            System.err.println("[ColorGradeRenderer] Vertex shader failed:\n" + GL20.glGetShaderInfoLog(vert));
            GL20.glDeleteShader(vert);
            failed = true;

            return;
        }

        int frag = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        GL20.glShaderSource(frag, FRAG);
        GL20.glCompileShader(frag);

        if (GL20.glGetShaderi(frag, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE)
        {
            System.err.println("[ColorGradeRenderer] Fragment shader failed:\n" + GL20.glGetShaderInfoLog(frag));
            GL20.glDeleteShader(vert);
            GL20.glDeleteShader(frag);
            failed = true;

            return;
        }

        program = GL20.glCreateProgram();
        GL20.glAttachShader(program, vert);
        GL20.glAttachShader(program, frag);
        GL20.glBindAttribLocation(program, 0, "a_pos");
        GL20.glBindAttribLocation(program, 1, "a_uv");
        GL20.glLinkProgram(program);
        GL20.glDeleteShader(vert);
        GL20.glDeleteShader(frag);

        if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == GL11.GL_FALSE)
        {
            System.err.println("[ColorGradeRenderer] Link failed:\n" + GL20.glGetProgramInfoLog(program));
            GL20.glDeleteProgram(program);
            failed = true;

            return;
        }

        uSampler = GL20.glGetUniformLocation(program, "u_sampler");
        uVigStr = GL20.glGetUniformLocation(program, "u_vigStr");
        uVigSmooth = GL20.glGetUniformLocation(program, "u_vigSmooth");
        uVigColor = GL20.glGetUniformLocation(program, "u_vigColor");
        uBrightness = GL20.glGetUniformLocation(program, "u_brightness");
        uContrast = GL20.glGetUniformLocation(program, "u_contrast");
        uSaturation = GL20.glGetUniformLocation(program, "u_saturation");
        uHue = GL20.glGetUniformLocation(program, "u_hue");
        uLift = GL20.glGetUniformLocation(program, "u_lift");
        uGamma = GL20.glGetUniformLocation(program, "u_gamma");
        uGain = GL20.glGetUniformLocation(program, "u_gain");
        uGrainStr = GL20.glGetUniformLocation(program, "u_grainStr");
        uGrainSize = GL20.glGetUniformLocation(program, "u_grainSize");
        uGrainSeed = GL20.glGetUniformLocation(program, "u_grainSeed");
        uDistort = GL20.glGetUniformLocation(program, "u_distort");
        uAberration = GL20.glGetUniformLocation(program, "u_aberration");
        uVHS = GL20.glGetUniformLocation(program, "u_vhs");
        uLensDistortion = GL20.glGetUniformLocation(program, "u_lensDistortion");
        uLensOverscan = GL20.glGetUniformLocation(program, "u_lensOverscan");
        uVintage = GL20.glGetUniformLocation(program, "u_vintage");
        uRadialBlur = GL20.glGetUniformLocation(program, "u_radialBlur");
        uRain = GL20.glGetUniformLocation(program, "u_rain");
        uDust = GL20.glGetUniformLocation(program, "u_dust");
        uLightLeak = GL20.glGetUniformLocation(program, "u_lightLeak");
        uHeatStrength = GL20.glGetUniformLocation(program, "u_heatStrength");
        uHeatSpeed = GL20.glGetUniformLocation(program, "u_heatSpeed");
        uHeatScale = GL20.glGetUniformLocation(program, "u_heatScale");
        uTime = GL20.glGetUniformLocation(program, "u_time");

        /* Fullscreen quad VAO/VBO (NDC coords + UV) */
        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();

        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);

        FloatBuffer buf = MemoryUtil.memAllocFloat(24);

        buf.put(new float[] {
            -1F, -1F,  0F, 0F,
             1F, -1F,  1F, 0F,
             1F,  1F,  1F, 1F,
            -1F, -1F,  0F, 0F,
             1F,  1F,  1F, 1F,
            -1F,  1F,  0F, 1F,
        }).flip();

        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buf, GL15.GL_STATIC_DRAW);
        MemoryUtil.memFree(buf);

        int stride = 4 * Float.BYTES;

        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, stride, 0L);
        GL20.glEnableVertexAttribArray(1);
        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, stride, (long) (2 * Float.BYTES));

        GL30.glBindVertexArray(0);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
    }
}
