package mchorse.bbs_mod.client;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.blocks.entities.ModelBlockEntity;
import mchorse.bbs_mod.camera.clips.misc.BossBarClip;
import mchorse.bbs_mod.camera.clips.misc.BossBarState;
import mchorse.bbs_mod.camera.clips.misc.ChromaSkyCurveSettings;
import mchorse.bbs_mod.camera.clips.misc.CurveClip;
import mchorse.bbs_mod.camera.clips.misc.HotbarClip;
import mchorse.bbs_mod.camera.clips.misc.HotbarState;
import mchorse.bbs_mod.camera.clips.misc.ImageClip;
import mchorse.bbs_mod.camera.clips.misc.ImageOverlay;
import mchorse.bbs_mod.camera.clips.misc.Subtitle;
import mchorse.bbs_mod.camera.clips.misc.SubtitleClip;
import mchorse.bbs_mod.camera.controller.CameraWorkCameraController;
import mchorse.bbs_mod.camera.controller.PlayCameraController;
import mchorse.bbs_mod.camera.data.Position;
import mchorse.bbs_mod.client.renderer.ModelBlockEntityRenderer;
import mchorse.bbs_mod.client.renderer.TriggerBlockEntityRenderer;
import mchorse.bbs_mod.client.screen.ScreenEffectRenderer;
import mchorse.bbs_mod.client.video.VideoRenderer;
import mchorse.bbs_mod.cubic.render.vao.ModelVAORenderer;
import mchorse.bbs_mod.events.ModelBlockEntityUpdateCallback;
import mchorse.bbs_mod.events.TriggerBlockEntityUpdateCallback;
import mchorse.bbs_mod.film.BaseFilmController;
import mchorse.bbs_mod.film.WorldFilmController;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.renderers.FormRenderer;
import mchorse.bbs_mod.forms.renderers.utils.BlockPaintOverlayVertexConsumer;
import mchorse.bbs_mod.forms.renderers.utils.BlockPaintOverlayVertexSodiumConsumer;
import mchorse.bbs_mod.forms.renderers.utils.BlockPaintVertexConsumer;
import mchorse.bbs_mod.forms.renderers.utils.BlockPaintVertexSodiumConsumer;
import mchorse.bbs_mod.forms.renderers.utils.GlowEmissionVertexConsumer;
import mchorse.bbs_mod.forms.renderers.utils.GlowEmissionVertexSodiumConsumer;
import mchorse.bbs_mod.forms.renderers.utils.TextGlowEmissionVertexConsumer;
import mchorse.bbs_mod.forms.renderers.utils.TextGlowEmissionVertexSodiumConsumer;
import mchorse.bbs_mod.forms.renderers.utils.RecolorVertexConsumer;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.graphics.texture.TextureFormat;
import mchorse.bbs_mod.ui.UIKeys;
import mchorse.bbs_mod.ui.dashboard.UIDashboard;
import mchorse.bbs_mod.ui.dashboard.WorldPropertiesHelper;
import mchorse.bbs_mod.ui.dashboard.panels.UIDashboardPanel;
import mchorse.bbs_mod.ui.film.UIBossBarRenderer;
import mchorse.bbs_mod.ui.film.UIFilmPanel;
import mchorse.bbs_mod.ui.film.UIHotbarRenderer;
import mchorse.bbs_mod.ui.film.UIImageRenderer;
import mchorse.bbs_mod.ui.film.UISubtitleRenderer;
import mchorse.bbs_mod.ui.framework.UIBaseMenu;
import mchorse.bbs_mod.ui.framework.UIRenderingContext;
import mchorse.bbs_mod.ui.framework.UIScreen;
import mchorse.bbs_mod.ui.framework.elements.utils.Batcher2D;
import mchorse.bbs_mod.ui.utils.Area;
import mchorse.bbs_mod.ui.utils.Gizmo;
import mchorse.bbs_mod.ui.utils.icons.Icons;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.VideoRecorder;
import mchorse.bbs_mod.utils.clips.Clip;
import mchorse.bbs_mod.utils.clips.ClipContext;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.iris.IrisUtils;
import mchorse.bbs_mod.utils.iris.ShaderCurves;
import mchorse.bbs_mod.utils.iris.ShaderOpacityPatch;
import mchorse.bbs_mod.utils.sodium.SodiumUtils;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.impl.client.rendering.WorldRenderContextImpl;
import net.fabricmc.loader.api.FabricLoader;
import net.irisshaders.iris.uniforms.custom.cached.CachedUniform;
import net.minecraft.class_1041;
import net.minecraft.class_2586;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4063;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_6364;
import net.minecraft.class_8251;
import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public class BBSRendering
{
    /**
     * Cached rendered model blocks
     */
    public static final Set<ModelBlockEntity> capturedModelBlocks = new HashSet<>();

    public static boolean canRender;

    public static boolean renderingWorld;
    private static boolean irisChunkLayerPass;
    public static int lastAction;

    public static final Matrix4f camera = new Matrix4f();

    /**
     * Iris world rendering multiplies the terrain {@code positionMatrix} into the
     * {@link class_4587} before entity transforms.
     * {@link Matrix4f#getTranslation()} on that product no longer equals the
     * camera-relative entity offset, so callers that rebuild world space from
     * translation + camera position must strip the terrain matrix first.
     */
    public static Matrix4f stripTerrainPositionMatrix(Matrix4f composed)
    {
        Matrix4f inverse = new Matrix4f(camera);

        inverse.invert();

        Matrix4f entity = new Matrix4f();

        inverse.mul(composed, entity);

        return entity;
    }

    private static boolean customSize;
    private static boolean iris;
    private static boolean sodium;
    private static boolean optifine;

    private static int width;
    private static int height;
    /**
     * Scale used for this frame's fisheye FOV widen (1 = off). Color grade reads this
     * so the UV warp matches the projection even if effect lists were rebuilt.
     */
    private static float lensOverscanScale = 1F;

    private static final UIBaseMenu replayHudMenu = new UIBaseMenu() {};

    private static boolean toggleFramebuffer;
    private static class_276 framebuffer;
    private static class_276 clientFramebuffer;
    private static Texture texture;
    private static class_4063 cachedCloudRenderMode;
    private static boolean cloudsForced;

    public static int getMotionBlur()
    {
        return getMotionBlur(BBSSettings.videoSettings.frameRate.get(), getMotionBlurFactor());
    }

    public static int getMotionBlur(double fps, int target)
    {
        int i = 0;

        while (fps < target)
        {
            fps *= 2;

            i++;
        }

        return i;
    }

    public static int getMotionBlurFactor()
    {
        return getMotionBlurFactor(BBSSettings.videoSettings.motionBlur.get());
    }

    public static int getMotionBlurFactor(int integer)
    {
        return integer == 0 ? 0 : (int) Math.pow(2, 6 + integer);
    }

    public static int getVideoWidth()
    {
        return width == 0 ? BBSSettings.videoSettings.width.get() : width;
    }

    public static int getVideoHeight()
    {
        return height == 0 ? BBSSettings.videoSettings.height.get() : height;
    }

    public static float getLensOverscanScale()
    {
        return lensOverscanScale;
    }

    public static void setLensOverscanScale(float scale)
    {
        lensOverscanScale = scale > 1.0001F ? scale : 1F;
    }

    public static int getVideoFrameRate()
    {
        int frameRate = BBSSettings.videoSettings.frameRate.get();

        return frameRate * (1 << getMotionBlur(frameRate, getMotionBlurFactor()));
    }

    public static File getVideoFolder()
    {
        File movies = new File(BBSMod.getSettingsFolder().getParentFile(), "movies");
        File exportPath = new File(BBSSettings.videoSettings.path.get());

        if (exportPath.isDirectory())
        {
            movies = exportPath;
        }

        movies.mkdirs();

        return movies;
    }

    public static boolean canReplaceFramebuffer()
    {
        return customSize && renderingWorld;
    }

    /**
     * Skip the vanilla world pass when the open BBS menu does not need it (opaque editors, film
     * home page, model editor, etc.). Panels that show the live world override
     * {@link UIBaseMenu#needsWorldRender()}.
     */
    public static boolean shouldSkipWorldRender()
    {
        UIBaseMenu menu = UIScreen.getCurrentMenu();

        return menu != null && !menu.needsWorldRender();
    }

    /**
     * Ensures paint overlays draw into the same framebuffer as the film viewport world pass.
     */
    public static void ensurePaintOverlayTargetFramebuffer()
    {
        if (toggleFramebuffer && framebuffer != null)
        {
            /* Keep the already-composited world; only re-bind. Clearing here wiped film
             * frames and made deferred translucent redraws (low Iris opacity) disappear. */
            framebuffer.method_1235(false);
            reassignFramebuffer(framebuffer);
        }
        else
        {
            /* World / non-film path: Iris may leave a different FBO bound at frame end. */
            class_310.method_1551().method_1522().method_1235(false);
        }
    }

    /**
     * Framebuffer whose color is sampled by ColorGradeOverlay (Iris-lit scene before regrade).
     */
    public static class_276 getPaintOverlaySourceFramebuffer()
    {
        if (toggleFramebuffer && framebuffer != null)
        {
            return framebuffer;
        }

        return class_310.method_1551().method_1522();
    }

    public static boolean isCustomSize()
    {
        return customSize;
    }

    public static void setCustomSize(boolean customSize)
    {
        setCustomSize(customSize, 0, 0);
    }

    public static void setCustomSize(boolean customSize, int w, int h)
    {
        BBSRendering.customSize = customSize;

        width = !customSize ? 0 : w;
        height = !customSize ? 0 : h;

        if (!customSize)
        {
            ensureMainFramebuffer();
            resizeExtraFramebuffers();
        }
    }

    /**
     * Model/trigger block panels render directly to the main framebuffer. If a film
     * session left {@link #toggleFramebuffer} enabled, the world keeps drawing offscreen
     * and only the cleared sky color is visible behind the UI.
     */
    public static void ensureMainFramebuffer()
    {
        if (!toggleFramebuffer)
        {
            return;
        }

        toggleFramebuffer(false);
    }

    /**
     * Reset GL state after mid-UI 3D form/model draws so later Batcher2D text is not
     * left with additive blend / depthMask false / grade uniforms (white doubled glyphs).
     */
    public static void restoreGuiRenderState()
    {
        ModelVAORenderer.clearFormColorGrade();
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.depthMask(true);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthFunc(GL11.GL_ALWAYS);
        GL11.glPolygonOffset(0F, 0F);
        GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);
    }

    public static Texture getTexture()
    {
        if (texture == null)
        {
            texture = new Texture();
            texture.setFormat(TextureFormat.RGB_U8);
            texture.setFilter(GL11.GL_NEAREST);
        }

        return texture;
    }

    public static void startTick()
    {
        class_310 mc = class_310.method_1551();

        /* Client ticks still run while the pause menu is open, but world/block-entity ticks do
         * not — clearing here would empty the set with nothing to refill it, killing model-block
         * Iris shadows (and UI lists that reuse this cache) until unpause. */
        if (mc != null && mc.method_1493())
        {
            return;
        }

        capturedModelBlocks.clear();
        TriggerBlockEntityRenderer.capturedTriggerBlocks.clear();
    }

    public static void setup()
    {
        iris = FabricLoader.getInstance().isModLoaded("iris");
        sodium = FabricLoader.getInstance().isModLoaded("sodium");
        optifine = FabricLoader.getInstance().isModLoaded("optifabric");

        ModelBlockEntityUpdateCallback.EVENT.register((entity) ->
        {
            if (entity.method_10997().method_8608())
            {
                capturedModelBlocks.add(entity);
            }
        });

        TriggerBlockEntityUpdateCallback.EVENT.register((entity) ->
        {
            if (entity.method_10997().method_8608())
            {
                TriggerBlockEntityRenderer.capturedTriggerBlocks.add(entity);
            }
        });

        if (!iris)
        {
            return;
        }

        IrisUtils.setup();
    }

    /* Framebuffers */

    public static class_276 getFramebuffer()
    {
        return framebuffer;
    }

    public static void setupFramebuffer()
    {
        class_1041 window = class_310.method_1551().method_22683();

        framebuffer = new class_6364(window.method_4489(), window.method_4506());
    }

    public static void resizeExtraFramebuffers()
    {
        Set<class_276> buffers = new HashSet<>();
        class_310 mc = class_310.method_1551();

        buffers.add(mc.field_1769.method_22990());
        buffers.add(mc.field_1769.method_29360());
        buffers.add(mc.field_1769.method_29361());
        buffers.add(mc.field_1769.method_29362());
        buffers.add(mc.field_1769.method_29363());
        buffers.add(mc.field_1769.method_29364());

        for (class_276 buffer : buffers)
        {
            resizeFramebuffer(buffer);
        }
    }

    public static void resizeFramebuffer(class_276 framebuffer)
    {
        if (framebuffer == null)
        {
            return;
        }

        class_310 mc = class_310.method_1551();
        int w = Math.max(2, mc.method_22683().method_4489());
        int h = Math.max(2, mc.method_22683().method_4506());

        if (framebuffer.field_1482 == w && framebuffer.field_1481 == h)
        {
            return;
        }

        framebuffer.method_1234(w, h, class_310.field_1703);
    }

    public static void toggleFramebuffer(boolean toggleFramebuffer)
    {
        if (toggleFramebuffer == BBSRendering.toggleFramebuffer)
        {
            return;
        }

        class_310 mc = class_310.method_1551();
        class_1041 window = mc.method_22683();

        BBSRendering.toggleFramebuffer = toggleFramebuffer;

        if (toggleFramebuffer)
        {
            int w = Math.max(2, mc.method_22683().method_4489());
            int h = Math.max(2, mc.method_22683().method_4506());

            resizeExtraFramebuffers();

            if (framebuffer.field_1482 != w || framebuffer.field_1481 != h)
            {
                framebuffer.method_1234(w, h, class_310.field_1703);
            }

            clientFramebuffer = mc.method_1522();

            reassignFramebuffer(framebuffer);

            framebuffer.method_1235(true);
        }
        else
        {
            class_276 target = clientFramebuffer != null ? clientFramebuffer : mc.method_1522();

            reassignFramebuffer(target);
            target.method_1235(true);

            int fbW = window.method_4489();
            int fbH = window.method_4506();

            if (width != 0 || customSize)
            {
                framebuffer.method_1237(fbW, fbH);
            }
        }
    }

    private static void reassignFramebuffer(class_276 framebuffer)
    {
        class_310.method_1551().field_1689 = framebuffer;
    }

    /* Rendering */

    public static void onWorldRenderBegin()
    {
        if (BBSRendering.shouldSkipWorldRender())
        {
            return;
        }

        class_310 mc = class_310.method_1551();
        BBSModClient.getFilms().startRenderFrame(mc.method_60646().method_60637(false));

        UIBaseMenu menu = UIScreen.getCurrentMenu();

        if (menu != null)
        {
            menu.startRenderFrame(mc.method_60646().method_60637(false));
        }

        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);

        renderingWorld = true;
        ShaderOpacityPatch.onWorldRenderBegin();
        updateCloudRenderMode(mc);
        ModelVAORenderer.clearPaintOverlayQueue();

        if (!customSize)
        {
            ensureMainFramebuffer();

            return;
        }

        toggleFramebuffer(true);
    }

    public static void onWorldRenderEnd()
    {
        if (BBSRendering.shouldSkipWorldRender())
        {
            return;
        }

        /* Paint overlays first (and noshading soft forms in the same queue, after paint via
         * sort). Iris soft forms (noshading off) already flushed at beginTranslucents. */
        ModelVAORenderer.flushPaintOverlayQueue();
        ShaderOpacityPatch.onWorldRenderEnd();

        class_310 mc = class_310.method_1551();
        UIBaseMenu currentMenu = UIScreen.getCurrentMenu();

        if (BBSModClient.getCameraController().getCurrent() instanceof PlayCameraController controller)
        {
            class_332 drawContext = new class_332(mc, mc.method_22940().method_23000());
            Batcher2D batcher = new Batcher2D(drawContext);
            class_1041 window = mc.method_22683();
            Area area = new Area(0, 0, window.method_4486(), window.method_4502());
            Matrix4f cache = new Matrix4f(RenderSystem.getProjectionMatrix());
            Matrix4f ortho = new Matrix4f().ortho(0, area.w, area.h, 0, -1000, 3000);

            RenderSystem.setProjectionMatrix(ortho, class_8251.field_43361);
            VideoRenderer.renderClips(batcher.getContext().method_51448(), batcher, controller.getContext().clips.getClips(controller.getContext().relativeTick), controller.getContext().relativeTick, true, area, area, null, area.w, area.h, false);

            ScreenEffectRenderer.render(batcher, controller.getContext(), area.w, area.h);
            renderHudOverlays(batcher, controller.getContext(), area.w, area.h);

            RenderSystem.setProjectionMatrix(cache, class_8251.field_43361);
        }

        if (BBSModClient.getVideoRecorder().isRecording() && BBSModClient.getCameraController().getCurrent() instanceof CameraWorkCameraController controller)
        {
            class_332 drawContext = new class_332(mc, mc.method_22940().method_23000());
            Batcher2D batcher = new Batcher2D(drawContext);
            class_1041 window = mc.method_22683();

            renderHudOverlays(batcher, controller.getContext(), window.method_4486(), window.method_4502());
        }

        if (!customSize)
        {
            renderingWorld = false;

            return;
        }

        if (currentMenu instanceof UIDashboard dashboard)
        {
            if (dashboard.getPanels().panel instanceof UIFilmPanel panel && panel.needsViewportRender())
            {
                class_332 drawContext = new class_332(mc, mc.method_22940().method_23000());
                Batcher2D offscreenBatcher = new Batcher2D(drawContext);

                class_1041 window = mc.method_22683();
                Matrix4f cache = new Matrix4f(RenderSystem.getProjectionMatrix());
                Matrix4f ortho = new Matrix4f().ortho(0, window.method_4486(), window.method_4502(), 0, -1000, 3000);

                RenderSystem.setProjectionMatrix(ortho, class_8251.field_43361);
                Area fullScreen = new Area(0, 0, window.method_4486(), window.method_4502());
                VideoRenderer.renderClips(new class_4587(), offscreenBatcher, panel.getData().camera.getClips(panel.getCursor()), panel.getCursor(), panel.getRunner().isRunning(), fullScreen, fullScreen, null, window.method_4486(), window.method_4502(), false);

                ScreenEffectRenderer.render(offscreenBatcher, panel.getRunner().getContext(), window.method_4486(), window.method_4502());
                renderHudOverlays(offscreenBatcher, panel.getRunner().getContext(), fullScreen.w, fullScreen.h);

                RenderSystem.setProjectionMatrix(cache, class_8251.field_43361);
            }
        }

        renderingWorld = false;
    }

    private static void updateCloudRenderMode(class_310 mc)
    {
        boolean shouldHideClouds = isChromaSkyEnabled() && !isChromaSkyClouds();

        if (shouldHideClouds)
        {
            if (!cloudsForced)
            {
                cachedCloudRenderMode = mc.field_1690.method_42528().method_41753();
                cloudsForced = true;
            }

            if (mc.field_1690.method_42528().method_41753() != class_4063.field_18162)
            {
                mc.field_1690.method_42528().method_41748(class_4063.field_18162);
            }
        }
        else if (cloudsForced)
        {
            if (cachedCloudRenderMode != null)
            {
                mc.field_1690.method_42528().method_41748(cachedCloudRenderMode);
            }

            cloudsForced = false;
        }
    }

    public static void onRenderBeforeScreen()
    {
        if (!toggleFramebuffer)
        {
            return;
        }

        Texture texture = getTexture();
        int prevRead = GL30.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);

        framebuffer.method_35610();

        texture.bind();
        texture.setSize(framebuffer.field_1482, framebuffer.field_1481);
        GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, 0, 0, framebuffer.field_1482, framebuffer.field_1481);
        texture.unbind();

        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, prevRead);

        toggleFramebuffer(false);
    }

    public static void onRenderChunkLayer(class_4587 stack)
    {
        WorldRenderContextImpl worldRenderContext = new WorldRenderContextImpl();
        class_310 mc = class_310.method_1551();

        worldRenderContext.prepare(
            mc.field_1769, mc.method_60646(), false,
            mc.field_1773.method_19418(), mc.field_1773, mc.field_1773.method_22974(),
            RenderSystem.getProjectionMatrix(), RenderSystem.getModelViewMatrix(), mc.method_22940().method_23000(), mc.method_16011(), false, mc.field_1687
        );

        if (!isIrisShadersEnabled())
        {
            renderCoolStuff(worldRenderContext);
        }
    }

    public static void onRenderChunkLayer(Matrix4f positionMatrix, Matrix4f projectionMatrix)
    {
    }

    public static void renderHud(class_332 drawContext, float tickDelta)
    {
        Batcher2D batcher2D = new Batcher2D(drawContext);
        VideoRecorder videoRecorder = BBSModClient.getVideoRecorder();

        BBSModClient.getFilms().renderHud(batcher2D, tickDelta);
        StructurePickerClient.renderHud(batcher2D);

        boolean showRecordingOverlay = videoRecorder.isRecording() && BBSSettings.recordingOverlays.get() && UIScreen.getCurrentMenu() == null;

        if (showRecordingOverlay)
        {
            int count = videoRecorder.getCounter();
            String label = UIKeys.FILM_VIDEO_RECORDING.format(
                count,
                BBSModClient.getKeyRecordVideo().method_16007().getString()
            ).get();

            int x = 5;
            int y = 5;
            int w = batcher2D.getFont().getWidth(label);

            batcher2D.box(x, y, x + 18 + w + 3, y + 16, Colors.A50);
            batcher2D.icon(Icons.SPHERE, Colors.RED | Colors.A100, x, y);
            batcher2D.textShadow(label, x + 18, y + 4);
        }

        if (UIScreen.getCurrentMenu() == null && BBSSettings.editorReplayHud.get())
        {
            renderSelectedReplayHud(drawContext, batcher2D, showRecordingOverlay ? 20 : 0);
        }
    }

    private static void renderSelectedReplayHud(class_332 drawContext, Batcher2D batcher2D, int yOffset)
    {
        Replay replay = BBSModClient.getSelectedReplay();

        if (replay == null)
        {
            return;
        }

        Form form = replay.form.get();
        String label = getReplayHudLabel(replay);
        boolean hasLabel = BBSSettings.editorReplayHudDisplayName.get() && !label.isEmpty();
        boolean hasForm = form != null;

        if (!hasForm && !hasLabel)
        {
            return;
        }

        int size = hasForm ? 24 : 0;
        int padding = 3;
        int gap = hasForm && hasLabel ? 4 : 0;

        int margin = 5;
        float textScale = 0.67F;
        int textWidth = hasLabel ? batcher2D.getFont().getWidth(label) : 0;
        int textHeight = hasLabel ? batcher2D.getFont().getHeight() : 0;
        int scaledTextWidth = Math.round(textWidth * textScale);
        int scaledTextHeight = Math.round(textHeight * textScale);
        int boxH = Math.max(size, scaledTextHeight) + padding * 2;
        int textBoxW = hasLabel ? scaledTextWidth + padding * 2 : 0;
        int totalW = (hasForm ? size : 0) + (hasLabel ? gap + textBoxW : 0);
        int x = getReplayHudX(margin, totalW);
        int y = getReplayHudY(margin + yOffset, boxH);
        int contentX = x + padding;
        int contentY = y + padding;

        int textBoxX = contentX + (hasForm ? size + gap : 0) - padding;
        int textBoxH = scaledTextHeight + padding * 2;
        int textBoxY = y + (boxH - textBoxH) / 2;

        if (hasLabel)
        {
            batcher2D.box(textBoxX, textBoxY, textBoxX + textBoxW, textBoxY + textBoxH, Colors.A50);
        }

        if (hasForm)
        {
            class_310 mc = class_310.method_1551();
            class_1041 window = mc.method_22683();

            replayHudMenu.resize(window.method_4486(), window.method_4502());
            replayHudMenu.context.setup(new UIRenderingContext(drawContext));

            int modelX1 = contentX;
            int modelY1 = contentY + (boxH - padding * 2 - size) / 2;
            int modelX2 = modelX1 + size;
            int modelY2 = modelY1 + size;

            try
            {
                FormRenderer.setSuppressFormDisplayName(true);
                FormUtilsClient.renderUI(form, replayHudMenu.context, modelX1, modelY1, modelX2, modelY2);
            }
            finally
            {
                FormRenderer.setSuppressFormDisplayName(false);
            }
        }

        if (hasLabel)
        {
            int textX = textBoxX + padding;
            int textY = textBoxY + padding;

            drawContext.method_51448().method_22903();
            drawContext.method_51448().method_22905(textScale, textScale, 1F);
            batcher2D.textShadow(label, textX / textScale, textY / textScale);
            drawContext.method_51448().method_22909();
        }
    }

    private static String getReplayHudLabel(Replay replay)
    {
        String label = replay.label.get();

        if (!label.isEmpty())
        {
            return label;
        }

        Form form = replay.form.get();

        return form == null ? "" : form.getDefaultDisplayNameForHud();
    }

    private static int getReplayHudX(int margin, int totalW)
    {
        int position = BBSSettings.editorReplayHudPosition.get();
        int screenW = class_310.method_1551().method_22683().method_4486();
        boolean right = position == 1 || position == 3;

        return right ? screenW - margin - totalW : margin;
    }

    private static int getReplayHudY(int margin, int boxH)
    {
        int position = BBSSettings.editorReplayHudPosition.get();
        int screenH = class_310.method_1551().method_22683().method_4502();
        boolean bottom = position == 2 || position == 3;
        int extraTopLeft = position == 0 ? 12 : 0;

        return bottom ? screenH - margin - boxH : margin + extraTopLeft;
    }

    public static void renderCoolStuff(WorldRenderContext worldRenderContext)
    {
        if (class_310.method_1551().field_1755 instanceof UIScreen screen)
        {
            screen.renderInWorld(worldRenderContext);
        }

        BBSModClient.getFilms().render(worldRenderContext);
    }

    public static boolean isOptifinePresent()
    {
        return optifine;
    }

    public static boolean isRenderingWorld()
    {
        return renderingWorld;
    }

    public static boolean isIrisChunkLayerPass()
    {
        return irisChunkLayerPass;
    }

    /**
     * Any Iris world draw (chunk-layer film/editor pass or entity/gbuffer pass). VAO models
     * must use the vanilla translucent program for the base pass so Iris can composite them;
     * the custom BBS model shader is only used for deferred paint/glow overlays.
     * Exception: form color alpha &lt; 1 must be deferred too — shader packs and vanilla
     * entity_translucent discard low vertex alpha; the BBS model shader only cuts out texture holes.
     */
    public static boolean isIrisWorldModelPass()
    {
        return isIrisShadersEnabled() && isRenderingWorld();
    }

    /**
     * With the Iris opacity fix, translucent opacities are redrawn after
     * VL clouds (post-deferred) so soft fades never punch the sky or get clouds composited
     * over the mesh. Near-opaque keeps the live Iris path with depth writes.
     */
    public static final float TRANSLUCENT_ALPHA_DISCARD_REF = 28F / 255F;

    /**
     * True when Iris would discard/mis-composite very low form opacity; queue a BBS redraw
     * after compositing. Slight opacity (e.g. {@code #e7}/{@code #fc}) stays on Iris.
     * When the Complementary/BSL opacity patch is active, never take this BBS handoff —
     * translucency stays on Iris and is flushed post-deferred after VL clouds (smooth
     * fade through {@code #1c}/28 with lighting and render depth intact).
     */
    public static boolean needsIrisTranslucentModelDeferral(float alpha)
    {
        if (!isIrisWorldModelPass() || isIrisShadowPass())
        {
            return false;
        }

        if (ShaderOpacityPatch.isActive())
        {
            return false;
        }

        return alpha < TRANSLUCENT_ALPHA_DISCARD_REF;
    }

    /**
     * Opt-in Opacity-track "No shading": redraw this soft form on the BBS deferred queue
     * after paint overlays (paint visible through soft; pack body sun shadows lost).
     * When off, soft forms stay on Iris post-deferred (body shadows kept; paint clipped).
     * Still applies when the Complementary/BSL opacity patch is active.
     */
    public static boolean needsIrisNoshadingOpacityDeferral(float alpha, boolean noshadingOpacity)
    {
        if (!noshadingOpacity || !isIrisWorldModelPass() || isIrisShadowPass())
        {
            return false;
        }

        return alpha > 0.001F && alpha < 0.999F;
    }

    /**
     * Iris live path keeps the user's alpha. Do not pull toward a sub-{@code alphaTestRef}
     * handoff — that made models vanish around {@code #2e}/{@code #2c} before the
     * {@code #1c}→{@code #1b} deferral switch.
     */
    public static float easeIrisModelAlpha(float alpha)
    {
        return alpha;
    }

    /**
     * Lift deferred alpha toward {@link #TRANSLUCENT_ALPHA_DISCARD_REF} so the first deferred
     * step ({@code #1b}) matches the last Iris step ({@code #1d}) — continuous handoff with
     * near-zero jump; deeper alphas stay near the user value.
     */
    public static float easeDeferredModelAlpha(float alpha)
    {
        if (!isIrisWorldModelPass() || isIrisShadowPass())
        {
            return alpha;
        }

        if (alpha <= 0F || alpha >= TRANSLUCENT_ALPHA_DISCARD_REF)
        {
            return alpha;
        }

        float t = alpha / TRANSLUCENT_ALPHA_DISCARD_REF;

        t = t * t * (3F - 2F * t);

        /* t→1 at #1b/#1c edge → ≈ REF (match Iris #1d); t→0 → stay near zero. */
        return alpha + (TRANSLUCENT_ALPHA_DISCARD_REF - alpha) * t;
    }

    /**
     * Deferred Iris low-alpha redraw ({@code #1b} and below): keep alpha, force RGB black
     * ({@code #aa000000}). White RGB on the BBS deferred path brightens vs Iris; black matches
     * the Iris handoff. Above the threshold the live Iris path keeps the user RGB ({@code ffffff}).
     */
    public static void applyDeferredModelHandoffRgb(Color color)
    {
        if (color == null)
        {
            return;
        }

        color.r = 0F;
        color.g = 0F;
        color.b = 0F;
    }

    /**
     * Flat forms (shape/billboard) through Iris translucent at any alpha &lt; 1 wash fog/sky.
     * Always defer them under Iris; they do not need pack mesh shading.
     */
    public static boolean needsIrisTranslucentFlatDeferral(float alpha)
    {
        return isIrisWorldModelPass() && !isIrisShadowPass() && alpha < 0.999F;
    }

    /**
     * Vanilla entity_translucent discards below {@link #TRANSLUCENT_ALPHA_DISCARD_REF}. Use for
     * Shape/Billboard without Iris: switch to the BBS model shader in-place with normal depth.
     */
    public static boolean needsBbsModelForLowOpacity(float alpha)
    {
        return !isIrisShadowPass() && alpha < TRANSLUCENT_ALPHA_DISCARD_REF;
    }

    /**
     * Iris entity/gbuffer pass (not the chunk-layer film/editor hook). Used to decide whether
     * paint overlays run immediately or are queued for {@code WorldRenderEvents.LAST}.
     */
    public static boolean isIrisDeferredModelPass()
    {
        return isIrisWorldModelPass() && !isIrisChunkLayerPass();
    }

    /**
     * When true, paint overlays must be queued for {@link ModelVAORenderer#flushPaintOverlayQueue()}
     * at the end of the world frame (Iris shader-pack path). Without Iris they run immediately
     * after each form so depth ordering against other entities stays correct.
     */
    public static boolean shouldDeferPaintOverlayToFrameEnd()
    {
        return isIrisWorldModelPass();
    }

    /**
     * When true, VAO model paint must not be applied in the base pass; use the BBS model
     * shader overlay ({@link ModelVAORenderer#submitPaintOverlay}) so paint matches under Iris.
     */
    public static boolean isIrisWorldPaintDeferral()
    {
        return isIrisWorldModelPass();
    }

    public static boolean isIrisLoaded()
    {
        return iris;
    }

    public static boolean isIrisShadersEnabled()
    {
        if (!iris)
        {
            return false;
        }

        return IrisUtils.isShaderPackEnabled();
    }

    public static void toggleShaders()
    {
        if (!iris)
        {
            return;
        }

        IrisUtils.toggleShaders();
    }

    public static void openShaderPackScreen()
    {
        if (!iris)
        {
            return;
        }

        IrisUtils.openShaderPackScreen();
    }

    public static boolean isIrisShadowPass()
    {
        if (!iris)
        {
            return false;
        }

        return IrisUtils.isShadowPass();
    }

    public static void trackTexture(Texture texture)
    {
        if (!iris)
        {
            return;
        }

        IrisUtils.trackTexture(texture);
    }

    public static void setPBRTextureIntensity(float normalIntensity, float specularIntensity)
    {
        if (!iris)
        {
            return;
        }

        IrisUtils.setPBRTextureIntensity(normalIntensity, specularIntensity);
    }

    public static void clearPBRTextureIntensity()
    {
        if (!iris)
        {
            return;
        }

        IrisUtils.clearPBRTextureIntensity();
    }

    public static float[] calculateTangents(float[] t, float[] v, float[] n, float[] u)
    {
        if (!iris)
        {
            return t;
        }

        return IrisUtils.calculateTangents(t, v, n, u);
    }

    public static float[] calculateTangents(float[] v, float[] n, float[] u)
    {
        if (!iris)
        {
            return v;
        }

        return IrisUtils.calculateTangents(v, n, u);
    }

    public static void addUniforms(List<CachedUniform> list, Map<String, ShaderCurves.ShaderVariable> variableMap)
    {
        if (!iris)
        {
            return;
        }

        IrisUtils.addUniforms(list, variableMap);
    }

    public static List<String> getShadersSliderOptions()
    {
        if (!iris)
        {
            return Collections.emptyList();
        }

        return IrisUtils.getSliderProperties();
    }

    public static Map<String, String> getShadersLanguageMap(String language)
    {
        if (!iris)
        {
            return Collections.emptyMap();
        }

        return IrisUtils.getShadersLanguageMap(language);
    }

    /* Curves */

    private static Double getCurveValue(String key)
    {
        if (!class_310.method_1551().method_18854())
        {
            return null;
        }

        if (BBSModClient.getCameraController().getCurrent() instanceof CameraWorkCameraController controller)
        {
            Map<String, Double> values = CurveClip.getValues(controller.getContext());

            if (values != null && values.containsKey(key))
            {
                return values.get(key);
            }
        }

        return getWorldFilmCurveValue(key);
    }

    /**
     * Curve values from an in-world film playback ({@link WorldFilmController}),
     * used when playing a film outside the BBS editor (no camera controller).
     */
    private static Double getWorldFilmCurveValue(String key)
    {
        for (BaseFilmController controller : BBSModClient.getFilms().getControllers())
        {
            if (!(controller instanceof WorldFilmController worldFilm))
            {
                continue;
            }

            if (worldFilm.hasFinished())
            {
                continue;
            }

            Map<String, Double> values = CurveClip.getValues(worldFilm.getCameraContext());

            if (values != null && values.containsKey(key))
            {
                return values.get(key);
            }
        }

        return null;
    }

    public static boolean isImmersiveWorldPanel()
    {
        UIBaseMenu menu = UIScreen.getCurrentMenu();

        if (!(menu instanceof UIDashboard dashboard))
        {
            return false;
        }

        UIDashboardPanel panel = dashboard.getPanels().panel;

        return panel != null && !panel.needsBackground();
    }

    /**
     * Chroma sky can hide terrain for film export and film editor preview, but
     * model/trigger block (and other world-editing) panels must always show the
     * live world behind their UI cards.
     */
    public static boolean shouldHideChromaTerrain()
    {
        if (!isChromaSkyEnabled() || isChromaSkyTerrain())
        {
            return false;
        }

        /* Film preview must match export: hide terrain when the toggle says so.
         * Other immersive panels (model/trigger editors, etc.) keep the world visible. */
        return !isImmersiveWorldPanel() || isFilmPanelOpen();
    }

    /**
     * Whether a specific block entity must be skipped while chroma sky is hiding terrain.
     * Model blocks can opt in (global setting overrides per-block).
     */
    public static boolean shouldHideChromaBlockEntity(class_2586 blockEntity)
    {
        if (!shouldHideChromaTerrain())
        {
            return false;
        }

        if (blockEntity instanceof ModelBlockEntity modelBlock)
        {
            return !shouldRenderModelBlockOnChroma(modelBlock);
        }

        return true;
    }

    /**
     * Global chroma-sky model-block setting takes precedence over the per-block toggle.
     */
    public static boolean shouldRenderModelBlockOnChroma(ModelBlockEntity modelBlock)
    {
        if (BBSSettings.chromaSkyModelBlocks.get())
        {
            return true;
        }

        return modelBlock.getProperties().isChromaSky();
    }

    private static boolean isFilmPanelOpen()
    {
        UIBaseMenu menu = UIScreen.getCurrentMenu();

        if (!(menu instanceof UIDashboard dashboard))
        {
            return false;
        }

        return dashboard.getPanels().panel instanceof UIFilmPanel;
    }

    public static boolean isChromaSkyEnabled()
    {
        ChromaSkyCurveSettings settings = getChromaSkySettings();

        return settings != null ? settings.enabled : BBSSettings.chromaSkyEnabled.get();
    }

    public static boolean isChromaSkyTerrain()
    {
        ChromaSkyCurveSettings settings = getChromaSkySettings();

        return settings != null ? settings.terrain : BBSSettings.chromaSkyTerrain.get();
    }

    public static boolean isChromaSkyClouds()
    {
        ChromaSkyCurveSettings settings = getChromaSkySettings();

        return settings != null ? settings.clouds : BBSSettings.chromaSkyClouds.get();
    }

    public static float getChromaSkyBillboard()
    {
        ChromaSkyCurveSettings settings = getChromaSkySettings();

        return settings == null ? BBSSettings.chromaSkyBillboard.get() : settings.billboard;
    }

    public static int getChromaSkyColor()
    {
        ChromaSkyCurveSettings settings = getChromaSkySettings();

        return settings == null ? BBSSettings.chromaSkyColor.get() : settings.color.getARGBColor();
    }

    private static ChromaSkyCurveSettings getChromaSkySettings()
    {
        if (getCurveValue(CurveClip.CHROMA_SKY_MARKER) == null)
        {
            return null;
        }

        if (BBSModClient.getCameraController().getCurrent() instanceof CameraWorkCameraController controller)
        {
            return CurveClip.getChromaSkySettings(controller.getContext());
        }

        return null;
    }

    public static Long getTimeOfDay()
    {
        Double v = getCurveValue(ShaderCurves.SUN_ROTATION);

        return v == null ? null : (long) (v * 1000L);
    }

    /**
     * Sun-path yaw in degrees. Film curve (editor or in-world playback) overrides
     * World Properties when present.
     */
    public static float getSunPathRotationDegrees()
    {
        Double v = getCurveValue(ShaderCurves.SUN_PATH_ROTATION);

        if (v != null)
        {
            return v.floatValue();
        }

        return WorldPropertiesHelper.getSunPathRotation();
    }

    public static Double getBrightness()
    {
        return getCurveValue(ShaderCurves.BRIGHTNESS);
    }

    public static Double getWeather()
    {
        return getCurveValue(ShaderCurves.WEATHER);
    }

    public static Function<class_4588, class_4588> getColorConsumer(Color color)
    {
        if (sodium)
        {
            return (b) -> SodiumUtils.createVertexBuffer(b, color);
        }

        return (b) -> new RecolorVertexConsumer(b, color);
    }

    public static Function<class_4588, class_4588> getColorConsumer(Color color, Color paintColor)
    {
        if (paintColor == null || paintColor.a == 0F)
        {
            return getColorConsumer(color);
        }

        if (sodium)
        {
            return (b) -> SodiumUtils.createVertexBuffer(b, color, paintColor);
        }

        return (b) -> new RecolorVertexConsumer(b, color, paintColor);
    }

    public static Function<class_4588, class_4588> getBlockPaintConsumer(Color color, Color paintColor)
    {
        if (paintColor == null || paintColor.a == 0F)
        {
            return getColorConsumer(color);
        }

        if (sodium)
        {
            return (b) -> new BlockPaintVertexSodiumConsumer(b, color, paintColor);
        }

        return (b) -> new BlockPaintVertexConsumer(b, color, paintColor);
    }

    public static Function<class_4588, class_4588> getGlowOverlayConsumer(Color glowColor)
    {
        if (sodium)
        {
            return (b) -> new GlowEmissionVertexSodiumConsumer(b, glowColor);
        }

        return (b) -> new GlowEmissionVertexConsumer(b, glowColor);
    }

    public static Function<class_4588, class_4588> getTextGlowOverlayConsumer(Color glowColor)
    {
        if (sodium)
        {
            return (b) -> new TextGlowEmissionVertexSodiumConsumer(b, glowColor);
        }

        return (b) -> new TextGlowEmissionVertexConsumer(b, glowColor);
    }

    public static Function<class_4588, class_4588> getBlockPaintOverlayConsumer(Color paintColor)
    {
        if (sodium)
        {
            return (b) -> new BlockPaintOverlayVertexSodiumConsumer(b, paintColor);
        }

        return (b) -> new BlockPaintOverlayVertexConsumer(b, paintColor);
    }

    /**
     * Neutral white vertex colors for block color-tint multiply overlays (tint lives in uniforms).
     */
    public static Function<class_4588, class_4588> getBlockColorTintOverlayConsumer()
    {
        return getColorConsumer(Color.white());
    }

    private static void renderHudOverlays(Batcher2D batcher, ClipContext context, int width, int height)
    {
        List<Subtitle> subtitles = SubtitleClip.getSubtitles(context);
        List<HotbarState> hotbars = HotbarClip.getHotbars(context);
        List<ImageOverlay> images = ImageClip.getImages(context);
        List<BossBarState> bossBars = BossBarClip.getBossBars(context);

        if (subtitles.isEmpty() && hotbars.isEmpty() && images.isEmpty() && bossBars.isEmpty())
        {
            return;
        }

        /* Safety net: Subtitle's text FBO can shrink glViewport; restore after the pass. */
        int[] prevViewport = new int[4];

        GL11.glGetIntegerv(GL11.GL_VIEWPORT, prevViewport);
        RenderSystem.disableDepthTest();

        class_4587 matrices = batcher.getContext().method_51448();
        int subtitleIndex = 0;
        int hotbarIndex = 0;
        int imageIndex = 0;
        int bossBarIndex = 0;

        while (subtitleIndex < subtitles.size() || hotbarIndex < hotbars.size() || imageIndex < images.size() || bossBarIndex < bossBars.size())
        {
            int subtitleOrder = subtitleIndex < subtitles.size() ? subtitles.get(subtitleIndex).renderOrder : Integer.MAX_VALUE;
            int hotbarOrder = hotbarIndex < hotbars.size() ? hotbars.get(hotbarIndex).renderOrder : Integer.MAX_VALUE;
            int imageOrder = imageIndex < images.size() ? images.get(imageIndex).renderOrder : Integer.MAX_VALUE;
            int bossBarOrder = bossBarIndex < bossBars.size() ? bossBars.get(bossBarIndex).renderOrder : Integer.MAX_VALUE;
            int nextOrder = Math.min(Math.min(subtitleOrder, hotbarOrder), Math.min(imageOrder, bossBarOrder));

            /* Draw lowest renderOrder first so higher timeline layers end up on top. */
            if (subtitleOrder == nextOrder)
            {
                UISubtitleRenderer.renderSubtitle(matrices, batcher, subtitles.get(subtitleIndex));
                subtitleIndex += 1;
            }
            else if (hotbarOrder == nextOrder)
            {
                UIHotbarRenderer.renderHotbar(matrices, batcher, hotbars.get(hotbarIndex), 0, 0, width, height);
                hotbarIndex += 1;
            }
            else if (imageOrder == nextOrder)
            {
                UIImageRenderer.renderImage(matrices, batcher, images.get(imageIndex));
                imageIndex += 1;
            }
            else
            {
                UIBossBarRenderer.renderBossBar(matrices, batcher, bossBars.get(bossBarIndex), 0, 0, width, height);
                bossBarIndex += 1;
            }
        }

        bossBars.clear();
        GL11.glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
        RenderSystem.enableDepthTest();
    }
}
